#ifndef FONCTION_H_
#define FONCTIONS_H_
#include <stdbool.h>


typedef struct Date
{

	int jour;
	int mois;
	int annee;
	
}Date; 

typedef struct {
char ref[30];
char marque[30];
char typeDeCapteur[30] ;
int BI;
int BS;
int  etat;  //(1: On , 0:OFF , 2:EnPanne)
Date dateMiseEnOeuvre ;

}Capteur;


void AjouterCapteur(Capteur c ) ;
void AfficherListCapteures(GtkWidget *liste) ;
void ModifierCapteur(Capteur c , char ref[30]) ;
void supprimerCapteur(char ref[30]) ;
void ChercherCapteur (GtkWidget *liste, char refe[30]) ;
int is_empty(GtkWidget *entry) ;
int existe(char ver[30]) ;








#endif
