#include <gtk/gtk.h>


void
AddCap                                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemoveCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectAddCap                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectUpdateCap                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
Refresh                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SearchCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
acceuil                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ModifierFN                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AllerHistoqrique                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RetourAcceuil                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AjouterHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectAddHis                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SuppHis                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
allerModifHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RefreshHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RetourCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SearchHis                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
modifierHis                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderRef                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackfromUpdate                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackfromUpHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
CapOn                                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapOff                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapPanne                               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapUpdateOn                            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapUpdateOff                           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapUpdatePannne                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
GoToAlaramant                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackFromAlarmante                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
