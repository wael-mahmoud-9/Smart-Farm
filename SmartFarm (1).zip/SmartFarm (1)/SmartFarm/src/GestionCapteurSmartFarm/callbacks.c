#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.c"
#include "twilio.c"
#include "historiqueCapteur.c"
#include <stdlib.h>
#include <unistd.h>


GtkWidget *afficher,*treeview ,*ajouter,*update;
int choix=0;
int x=0;


int is_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}


int existe(char ver[30]) {
FILE *f;
f = fopen("capteurs.txt","r");
int find=0;
char ref[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,ref)!=EOF)
{
if(strcmp(ver,ref)==0)
find=1;
}
}
else
printf("erreur \n");
return find;
}

void
AddCap                                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	Capteur p;
	GtkWidget *reference,*type,*marque,*bi,*bs,*jour, *mois, *annee, *ajouter,*pInfo ;
	char ver[30];

	reference=lookup_widget(objet_graphique,"RefEntry");
	type=lookup_widget(objet_graphique,"ComboType");
	marque=lookup_widget(objet_graphique,"MarqueEntry");

	bi=lookup_widget(objet_graphique, "spinbuttonBI");
	bs=lookup_widget(objet_graphique, "spinbuttonBS");
	jour=lookup_widget(objet_graphique, "spinbuttonJ");
	mois=lookup_widget(objet_graphique, "spinbuttonM");
	annee=lookup_widget(objet_graphique, "spinbuttonA");

if( (is_empty(reference)==0) /*|| (is_empty(type)==0) */|| (is_empty(marque)==0) || (is_empty(bi)==0) 
 || (is_empty(bs)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"Cntrl");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_entry_get_text(GTK_ENTRY(reference)));
	if(existe(ver)==1)
{
	GtkWidget *existe=lookup_widget(objet_graphique,"Existe");
        gtk_label_set_text(GTK_LABEL(existe),"reference existe deja !");
}
else {

	
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	strcpy(p.typeDeCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
	strcpy(p.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
	
	p.dateMiseEnOeuvre.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateMiseEnOeuvre.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateMiseEnOeuvre.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	if( choix == 0 )
	{

	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_ERROR,
	GTK_BUTTONS_OK,
	"Vous devez choisir \n l'etat du capteur SVP");
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{
	gtk_widget_destroy(pInfo);
	
	}

	}
else {
	if( choix == 1 )
	{
	p.etat = 1;
	}
	if( choix == 2 )
	{
	p.etat = 2;
	}
	if( choix == 3 )
	{
	p.etat = 3;
	}


	p.BI=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bi));
	p.BS=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bs));

	if((p.dateMiseEnOeuvre.jour >= 32) || (p.dateMiseEnOeuvre.mois >= 13) ||  (p.dateMiseEnOeuvre.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"FormatDate");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	AjouterCapteur(p);
	
	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_INFO,
	GTK_BUTTONS_OK,
	"Ajout avec succée de : %s",p.typeDeCapteur);
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{
	ajouter=lookup_widget(objet_graphique,"InterfaceAddCapteurAdmin");
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListCapteures(treeview);
	}
	

}
}
}
}
}


void
RemoveCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cet Capteur ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

	
        
        p=lookup_widget(objet_graphique,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           
		
        supprimerCapteur(id);
		SupprimerValeur2(id);
		printf("id supprimer est : %s \n",id);
		
		char tt[80];
		strcpy(tt,"Un capteur qui a la référence -");
		strcat(tt,id);
		strcat(tt,"- a été supprimer avec succés :) ");
	
	twilio_send_message("AC36519c8d5b3d7c49ae1397cb6196de86",
			    "27508283f178a45b113555b7ebd5b0a2",
			    tt,
			    "+12056795511",
			    //"21651078016",
			    "21623422387",
			    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSF9GM5mq97W_EPvDu7JH_n_VR9ZsOTEWQq4Q&usqp=CAU",
			     true);
	
	ajouter=lookup_widget(objet_graphique,"ListCapteures");
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListCapteures(treeview);
	
        }
           
	
	
	gtk_widget_destroy(pQuestion);
           


	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}


}


void
RedirectAddCap                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"ListCapteures");
	ajouter = create_InterfaceAddCapteurAdmin();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);

}


void
RedirectUpdateCap                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *w2,*w1;
	w1 = lookup_widget(objet_graphique, "ListCapteures") ;
	w2 = lookup_widget(objet_graphique, "ModificationCapteur") ;
	w2 = create_ModificationCapteur();
	gtk_widget_show (w2);
	gtk_widget_hide (w1);

}


void
Refresh                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"ListCapteures");
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListCapteures(treeview);

}


void
SearchCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry1") ;
	w1=lookup_widget(objet_graphique,"ListCapteures");
	if((is_empty(search)==0)  )
	{
		GtkWidget *control=lookup_widget(objet_graphique,"Cntrl1");
                gtk_label_set_text(GTK_LABEL(control),"Champ manquant!!");

	}
	else {
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	ChercherCapteur(treeview,ss);
	}
}


void
acceuil                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceAddCapteurAdmin");
	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview1") ;
	AfficherListCapteures(treeview);

}


void
ModifierFN                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

Capteur p;
	GtkWidget *reference,*ref1,*type,*marque,*bi,*bs,*jour, *mois, *annee, *ajouter, *update,*pInfo ;
	char ver[30];

	
	ref1=lookup_widget(objet_graphique,"combobox3");
	type=lookup_widget(objet_graphique,"combo1Type");
	marque=lookup_widget(objet_graphique,"Marque1Entry");

	bi=lookup_widget(objet_graphique, "spinbutton1BI");
	bs=lookup_widget(objet_graphique, "spinbutton1BS");
	jour=lookup_widget(objet_graphique, "spinbutton1J");
	mois=lookup_widget(objet_graphique, "spinbutton1M");
	annee=lookup_widget(objet_graphique, "spinbutton1A");

if(  (is_empty(marque)==0) || (is_empty(bi)==0) 
 || (is_empty(bs)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"Remplir");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));
	

	
	strcpy(p.ref,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));
	strcpy(p.typeDeCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
	strcpy(p.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
	if( x == 0 )
	{

	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_INFO,
	GTK_BUTTONS_OK,
	"Vous devez choisir \n l'etat du Capteur ?");
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{
	gtk_widget_destroy(pInfo);
	
	}

	}
	if( x == 1 )
	{
	p.etat = 1;
	}
	if( x == 2 )
	{
	p.etat = 2;
	}
	if( x == 3 )
	{
	p.etat = 3;
	}
	
	p.dateMiseEnOeuvre.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateMiseEnOeuvre.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateMiseEnOeuvre.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));


	p.BI=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bi));
	p.BS=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bs));

	if((p.dateMiseEnOeuvre.jour >= 32) || (p.dateMiseEnOeuvre.mois >= 13) ||  (p.dateMiseEnOeuvre.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"DateF");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierCapteur(p,ver);
	
	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_INFO,
	GTK_BUTTONS_OK,
	"Modification avec succée \n de capteur ayant la référence : %s",p.ref);
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{

	update=lookup_widget(objet_graphique,"ModificationCapteur");
	
	

	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (update);
	treeview = lookup_widget(ajouter, "treeview1") ;
	AfficherListCapteures(treeview);
	}

	
	
	


}
}

}


void
AllerHistoqrique                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	afficher=lookup_widget(objet_graphique,"ListCapteures");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview2") ;
	AfficherHistorique(treeview);

}


void
RetourAcceuil                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceAjout_h");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
        treeview = lookup_widget(ajouter, "treeview2") ;
	AfficherHistorique(treeview);

}


void
AjouterHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	historiqueCapteur p;
	GtkWidget *reference,*refCap,*valeur,*jour, *mois, *annee, *ajouter ;
	char ver[30];

	refCap=lookup_widget(objet_graphique,"combobox1");
	
	reference=lookup_widget(objet_graphique,"entry7");
	valeur=lookup_widget(objet_graphique,"spinbutton8");
	jour=lookup_widget(objet_graphique, "spinbutton9");
	mois=lookup_widget(objet_graphique, "spinbutton10");
	annee=lookup_widget(objet_graphique, "spinbutton12");

if( (is_empty(valeur)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"label61");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	

	
	strcpy(p.refCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(refCap)));
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	
	
	
	p.datePreleveemnt.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.datePreleveemnt.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.datePreleveemnt.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));
	

	if((p.datePreleveemnt.jour >= 32) || (p.datePreleveemnt.mois >= 13) ||  (p.datePreleveemnt.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label62");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	AjouterValeur(p);

	afficher=lookup_widget(objet_graphique,"InterfaceAjout_h");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	
	treeview = lookup_widget(ajouter, "treeview2") ;
	AfficherHistorique(treeview);


}
}



}


void
RedirectAddHis                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	afficher=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	ajouter = create_InterfaceAjout_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);

}


void
SuppHis                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cette valeur ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

	
        
        p=lookup_widget(objet_graphique,"treeview2");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           
			//printf("id est : %s \n",id);
           SupprimerValeur(id);
	ajouter=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherHistorique(treeview);
	
        }
           
	
	
	gtk_widget_destroy(pQuestion);
           


	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}

}


void
allerModifHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *w2,*w1;
	w1 = lookup_widget(objet_graphique, "InterfaceAfficher_h") ;
	w2 = lookup_widget(objet_graphique, "InterfaceUpdate_h") ;
	w2 = create_InterfaceUpdate_h();
	gtk_widget_show (w2);
	gtk_widget_hide (w1);

}


void
RefreshHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherHistorique(treeview);
	

}


void
RetourCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview1") ;
	AfficherListCapteures(treeview);

}


void
SearchHis                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry6") ;
	w1=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	if((is_empty(search)==0)  )
	{
		GtkWidget *control=lookup_widget(objet_graphique,"label76");
                gtk_label_set_text(GTK_LABEL(control),"Champ manquant!!");

	}
	else {
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview2") ;
	ChercherValeur(treeview,ss);
	}

}


void
modifierHis                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	historiqueCapteur p;
	GtkWidget *reference,*refCap,*valeur,*jour, *mois, *annee, *ajouter ;
	char ver[30];


	refCap=lookup_widget(objet_graphique,"combobox2");
	reference=lookup_widget(objet_graphique,"combobox4");
	valeur=lookup_widget(objet_graphique,"spinbutton4");
	jour=lookup_widget(objet_graphique, "spinbutton5");
	mois=lookup_widget(objet_graphique, "spinbutton6");
	annee=lookup_widget(objet_graphique, "spinbutton7");

if(    (is_empty(valeur)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"label69");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	

	
	strcpy(p.refCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(refCap)));
	strcpy(p.ref,gtk_combo_box_get_active_text(GTK_COMBO_BOX(reference)));
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(reference)));
	

	
	p.datePreleveemnt.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.datePreleveemnt.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.datePreleveemnt.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));
	

	if((p.datePreleveemnt.jour >= 32) || (p.datePreleveemnt.mois >= 13) ||  (p.datePreleveemnt.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label70");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierValeur(p,ver);

	ajouter=lookup_widget(objet_graphique,"InterfaceUpdate_h");
	
	
	gtk_widget_hide (ajouter);
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherHistorique(treeview);


}
}


}


void
ValiderRef                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox1");
	btn=lookup_widget(objet_graphique,"Valider");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference.txt");

}


void
ValiderModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox4");
	btn=lookup_widget(objet_graphique,"button14");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef1();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference1.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference1.txt");

}


void
RemplirModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *ref,*refCapteur,*val,*annee,*jour,*mois;

	refCapteur=lookup_widget(objet_graphique,"combobox2");
	ref=lookup_widget(objet_graphique,"combobox4");
	val=lookup_widget(objet_graphique,"spinbutton4");
	
	jour=lookup_widget(objet_graphique,"spinbutton5");
	mois=lookup_widget(objet_graphique,"spinbutton6");
	annee=lookup_widget(objet_graphique,"spinbutton7");

	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref)));	
	historiqueCapteur c;
	FILE *f=NULL;
	f = fopen("historiqueCapteur.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)

	{
	if(strcmp(var,c.ref)==0)
	{
	
	gtk_spin_button_set_value (val, c.valeur);
	gtk_combo_box_append_text (GTK_COMBO_BOX(refCapteur),(c.refCapteur));
	gtk_spin_button_set_value (annee, c.datePreleveemnt.annee);
	gtk_spin_button_set_value (mois, c.datePreleveemnt.mois);
	gtk_spin_button_set_value (jour, c.datePreleveemnt.jour);

	}

	
	}
	}
	fclose(f);

}


void
ValiderCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox3");
	btn=lookup_widget(objet_graphique,"button16");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference.txt");

}


void
RemplirCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *ref1,*type,*marque,*bi,*on,*off,*panne,*bs,*etat,*annee,*jour,*mois;

	ref1=lookup_widget(objet_graphique,"combobox3");
	type=lookup_widget(objet_graphique,"combo1TYpe");
	marque=lookup_widget(objet_graphique,"Marque1Entry");
	
	bi=lookup_widget(objet_graphique,"spinbutton1BI");
	bs=lookup_widget(objet_graphique,"spinbutton1BS");


	jour=lookup_widget(objet_graphique,"spinbutton1J");
	mois=lookup_widget(objet_graphique,"spinbutton1M");
	annee=lookup_widget(objet_graphique,"spinbutton1A");
	on=lookup_widget(objet_graphique,"checkbutton4");
	off=lookup_widget(objet_graphique,"checkbutton5");
	panne=lookup_widget(objet_graphique,"checkbutton6");

	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));	
	Capteur c;
	FILE *f=NULL;
	f = fopen("capteurs.txt","r");
	if(f!=NULL)
	{while (fscanf(f,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF)

	{
	if(strcmp(var,c.ref)==0)
	{
	gtk_entry_set_text (marque,c.marque);
	gtk_combo_box_append_text (GTK_COMBO_BOX(type),(c.typeDeCapteur));
	gtk_spin_button_set_value (bi, c.BI);
	gtk_spin_button_set_value (bs, c.BS);
if(c.etat == 0)
{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(off), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(on), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(panne), FALSE);
}
if(c.etat== 1)
{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(on), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(off), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(panne), FALSE);
}
if(c.etat== 2)
{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(panne), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(on), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(off), FALSE);
}

	gtk_spin_button_set_value (jour, c.dateMiseEnOeuvre.jour);
	gtk_spin_button_set_value (mois, c.dateMiseEnOeuvre.mois);
	gtk_spin_button_set_value (annee, c.dateMiseEnOeuvre.annee);

	}

	
	}
	}
	fclose(f);

}


void
BackfromUpdate                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	afficher=lookup_widget(objet_graphique,"ModificationCapteur");
	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview1") ;
	AfficherListCapteures(treeview);

}


void
BackfromUpHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceUpdate_h");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview2") ;
	AfficherHistorique(treeview);

}


void
CapOn                                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
choix=1;

}


void
CapOff                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
choix=3;

}


void
CapPanne                               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
choix=2;

}


void
CapUpdateOn                            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
x=1;

}


void
CapUpdateOff                           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
x=3;

}


void
CapUpdatePannne                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
x=2;

}


void
GoToAlaramant                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	lirefscanf();
	afficher=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	ajouter = create_CapAlarmante();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview3") ;
	AfficherAlarmante(treeview);
	

	
	
	

}


void
BackFromAlarmante                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{	
	remove("fichierTestAlaramante.txt");
	GtkWidget *treeview;
	afficher=lookup_widget(objet_graphique,"CapAlarmante");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview2") ;
	AfficherHistorique(treeview);

}

