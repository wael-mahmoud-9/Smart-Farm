#ifndef FONCTION_H_
#define FONCTIONS_H_
#include <stdbool.h>


typedef struct Datee
{

	int jour;
	int mois;
	int annee;
	
}Datee;

typedef struct  {
char ref[30];
char refCapteur[30];
int valeur;
Datee datePreleveemnt ;
} historiqueCapteur;

void AjouterValeur(historiqueCapteur hc) ;
void AfficherHistorique(GtkWidget *liste) ;
void ModifierValeur( historiqueCapteur hc , char ref[30]) ;
void SupprimerValeur(char ref[30]) ;
void ChercherValeur (GtkWidget *liste, char refe[30]) ;
void CapAlarmantes() ;
void Verification(/*int valeur,char refCap[30]*/);





#endif
