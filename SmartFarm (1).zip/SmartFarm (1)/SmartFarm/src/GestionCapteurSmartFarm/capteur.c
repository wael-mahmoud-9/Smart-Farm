#include "capteur.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


enum   
{       REF,
        TYPE,
	MARQUE,
	BI,
	BS,
        DATE,
	ETAT,
	COLUMNS,
	
};

///////////////////////Séparation


void AjouterCapteur(Capteur c)
{

FILE *f=NULL;

f=fopen("capteurs.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %s %d %d %d %d %d %d \n",c.ref,c.typeDeCapteur,c.marque,c.BI,c.BS,c.etat,c.dateMiseEnOeuvre.annee,
c.dateMiseEnOeuvre.mois,c.dateMiseEnOeuvre.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
}

///////////////////////Séparation



void supprimerCapteur(char ref[30]){

FILE*f=NULL;
FILE*f1=NULL;
Capteur c;
f=fopen("capteurs.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF)
{
if(strcmp(ref,c.ref)!=0)
{
fprintf(f1,"%s %s %s %d %d %d %d %d %d \n",c.ref,c.typeDeCapteur,c.marque,c.BI,c.BS,c.etat,c.dateMiseEnOeuvre.annee,
c.dateMiseEnOeuvre.mois,c.dateMiseEnOeuvre.jour);
}
}

fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("ancien.txt","capteurs.txt");
}

///////////////////////Séparation

void ModifierCapteur(Capteur c , char ref[30]) {

supprimerCapteur(ref);
AjouterCapteur(c);

}


///////////////////////Séparation


void ChercherCapteur ( GtkWidget *liste, char refe[30]) {

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char type[30];
	char marque[30];
	char bi[30];
	char bs[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char etat[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Type de capteur",renderer, "text",TYPE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",MARQUE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Etat",renderer, "text",ETAT, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BI",renderer, "text",BI, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BS",renderer, "text",BS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING
		, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("capteurs.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("capteurs.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s %s %s \n " ,ref,type,marque,bi,bs,etat,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
if(strcmp(refe,ref)==0 || strcmp(refe,type)==0  || strcmp(refe,marque)==0 || strcmp(refe,bi)==0 || strcmp(refe,bs)==0
|| strcmp(refe,annee)==0 ) 			
		
		{
		gtk_list_store_append (store,&iter);

		if(strcmp(etat,"3")==0)
		{
		gtk_list_store_set (store, &iter, REF,ref, TYPE,type, MARQUE,marque, BI,bi ,BS,bs , ETAT,"OFF", DATE,dateComp, -1 );
		}if(strcmp(etat,"1")==0)
		{
		gtk_list_store_set (store, &iter, REF,ref, TYPE,type, MARQUE,marque, BI,bi ,BS,bs , ETAT,"ON", DATE,dateComp, -1 );
		}if(strcmp(etat,"2")==0)
		{
		gtk_list_store_set (store, &iter, REF,ref, TYPE,type, MARQUE,marque, BI,bi ,BS,bs , ETAT,"En panne", DATE,dateComp,-1 );
		}
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


int is_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}


int existe(char ver[30]) {
FILE *f;
f = fopen("capteurs.txt","r");
int find=0;
char ref[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,ref)!=EOF)
{
if(strcmp(ver,ref)==0)
find=1;
}
}
else
printf("erreur \n");
return find;
}



}

void AfficherListCapteures(GtkWidget *liste) {


GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char type[30];
	char marque[30];
	char bi[30];
	char bs[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char etat[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Type de capteur",renderer, "text",TYPE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",MARQUE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Etat",renderer, "text",ETAT, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BI",renderer, "text",BI, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BS",renderer, "text",BS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING
		, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("capteurs.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("capteurs.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s %s %s \n " ,ref,type,marque,bi,bs,etat,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		
		gtk_list_store_append (store,&iter);

		if(strcmp(etat,"3")==0)
		{
		gtk_list_store_set (store, &iter, REF,ref, TYPE,type, MARQUE,marque, BI,bi ,BS,bs , ETAT,"OFF", DATE,dateComp, -1 );
		}if(strcmp(etat,"1")==0)
		{
		gtk_list_store_set (store, &iter, REF,ref, TYPE,type, MARQUE,marque, BI,bi ,BS,bs , ETAT,"ON", DATE,dateComp, -1 );
		}if(strcmp(etat,"2")==0)
		{
		gtk_list_store_set (store, &iter, REF,ref, TYPE,type, MARQUE,marque, BI,bi ,BS,bs , ETAT,"En panne", DATE,dateComp, 			-1 );
		}
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}

}

/*
void extractVersTableau()
{
    
    Capteur tab[500][5000];
	Capteur c;
    //char c;
    int k, i=0, j=0; // k indice de lecture des lignes, i nombre de lignes, j indice caractère 
 
    FILE *file = fopen("capteurs.txt","r");
   // FILE *f = fopen("equipement.txt","r");
    //FILE *f1 = fopen("marrque.txt","a+");
    if (file == NULL)
       printf("erreur");
 /*
    //c = fgetc(file); // lecture du 1er caractère du fichier 
    while (fscanf(file,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF) // Tant qu'on est pas en fin de fichier 
    {
       
            strcpy(tab[i][j].ref,c.ref);
			strcpy(tab[i][j].typeDeCapteur,c.typeDeCapteur);
			strcpy(tab[i][j].marque,c.marque);
			tab[i][j].BI = c.BI;
			tab[i][j].BS = c.BS;
			tab[i][j].etat = c.etat;
			tab[i][j].dateMiseEnOeuvre.annee = c.dateMiseEnOeuvre.annee;
			tab[i][j].dateMiseEnOeuvre.mois = c.dateMiseEnOeuvre.mois;
			tab[i][j].dateMiseEnOeuvre.jour = c.dateMiseEnOeuvre.jour;
			 // affectation du caractère à l'index j 
            j++; // index suivant pour le caractère suivant 
            
        
 
        //c.dateMiseEnOeuvre.jour = fgetc(file); // lecture du prochaine caractère 
        
		for (k=0; k<i; k++)
		printf("%s\n", tab[k]);
    }
 */
    //fclose(file);
 
   /*
    if (file == NULL)
        exit(EXIT_FAILURE);
    char ref[30];
    char marque[30];
    char type[30];
    int dispo;
    int jour;
    int mois;
    int annee;
    while (fscanf(f,"%s %s %s %d %d %d %d \n " ,ref,marque,type,&dispo,&annee,&mois,&jour)!=EOF)
    {
        for (k=0; k<i; k++)
        {
            char test[30];
            strcpy(test,tab[k]);
            //printf("%s\n", ref);
            
            if(atoi(test) == atoi(ref) )
            fprintf(f1,"%s \n",marque);
            
        }
    }
    fclose(f);
    fclose(f1);
*/
//}
//

int compteDonnees()
{
 char lignes[200];
 int nbLignes=0;
 
 FILE * fp;
 
 // ouverture fichier et verif
 if ((fp=fopen ("capteurs.txt","r")) == NULL)
 printf("Impossible d'ouvrir le fichier données en lecture\n");
 
 // lecture ligne par ligne
 // while (!=feof(fp))
 while(fgets(lignes,200,fp)!= NULL){
 nbLignes++;
 //fscanf(fp,"%s %s %d %d %d\n",ligne);
 }
 
 fclose (fp);
 return nbLignes;
}


void lirefscanf ()
{
  
  int i,nbLignes;
 
  FILE * fp;
  FILE * f;
  FILE * f1;
 
 nbLignes=compteDonnees();
 printf("%d\n", nbLignes);
 
 Capteur  sauveDonnee[nbLignes];
 // ouverture fichier et verif
 fp=fopen ("capteurs.txt","r");
 if (fp == NULL)
 printf("Impossible d'ouvrir le fichier données en lecture\n");
 
 for(i=0; i<nbLignes;i++)
 {
  fscanf(fp,"%s %s %s %d %d %d %d %d %d \n",sauveDonnee[i].ref, sauveDonnee[i].typeDeCapteur, 
  sauveDonnee[i].marque, &sauveDonnee[i].BI, &sauveDonnee[i].BS, &sauveDonnee[i].etat, &sauveDonnee[i].dateMiseEnOeuvre.annee, &sauveDonnee[i].dateMiseEnOeuvre.mois, &sauveDonnee[i].dateMiseEnOeuvre.jour);
 }
 
 fclose (fp);
 char ref[30];
 char refCapteur[30];
 int valeur=0;
 int annee=0;
 int mois=0;
 int jour=0;
f=fopen ("historiqueCapteur.txt","r");
f1=fopen ("fichierTestAlaramante.txt","a+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,ref,refCapteur,&valeur,&annee,&mois,&jour)!=EOF)
	 {
	 //printf("premier boucle \n");
	 
	for(i=0; i<nbLignes;i++)
 	{
	 //printf("%s %s\n", sauveDonnee[i].typeDeCapteur,sauveDonnee[i].marque);
	// printf("deuxieme boucle \n");
	 if((strcmp(refCapteur,sauveDonnee[i].ref)==0) && ((valeur >= sauveDonnee[i].BS) || ( sauveDonnee[i].BI >= valeur)))
	 {
		 printf("%s %d %d\n", sauveDonnee[i].ref,sauveDonnee[i].BI,sauveDonnee[i].BS);
		 fprintf(f1,"%s %s %d %d %d %d %d %d \n",refCapteur,sauveDonnee[i].typeDeCapteur,valeur,sauveDonnee[i].BI,sauveDonnee[i].BS,annee,mois,jour);
	 }
	 }
 }
 fclose(f);
 fclose(f1);

}





