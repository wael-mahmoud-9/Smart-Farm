
#include <stdio.h>
#include <stdlib.h>
#include "capteur.c"
#include "historiqueCapteur.c"

int main ()
{

//*******************************   Fonction Ajouter Historique *******************************


/*

historiqueCapteur hc;
printf("\n Saisie du reference du capteur: ");
scanf("%s",hc.ref);

printf("\n Saisie la Valeur du Capteur : ");
scanf("%s",hc.valeur);

printf("\n Saisie la datePreleveemnt: ");
scanf("%s",hc.datePreleveemnt);

AjouterValeur(hc);

printf(" ###  Ajout avec succés  ### \n");
*/



//*******************************   Fonction Afficher Historique ******************************* 


 
/*

historiqueCapteur hc;
FILE *f=NULL;

f=fopen("/home/ala/Projects/SmartFarm/src/historiqueCapteur.txt","r+");

if(f!=NULL)
{
while (fscanf(f,"%s %s %s \n ",hc.ref,hc.valeur,hc.datePreleveemnt)!=EOF)
  
printf("*Référence :%s | *Valeur :%s | *Date de prelevement :%s   \n",hc.ref,hc.valeur,hc.datePreleveemnt);
fclose(f);
}


else 
{
printf("Impossible d'ouvrir le fichier");
}
*/

//********************************* Fonction Supprimer Historique ******************************* 
/*

SupprimerValeur("113");
printf(" ###  Suppression avec succés  ### \n");

/*
//*******************************  Fonction Modifier Historique ******************************* 




/*
char ref1[30];
historiqueCapteur hc;

printf("\n Saisie du reference du capteur a modifier: ");
scanf("%s",ref1);


printf("\n Saisie du reference du capteur: ");
scanf("%s",hc.ref);

printf("\n Saisie la Valeur du Capteur : ");
scanf("%s",hc.valeur);

printf("\n Saisie la datePreleveemnt: ");
scanf("%s",hc.datePreleveemnt);

ModifierValeur(hc,ref1);

SupprimerValeur("123");
printf(" ###  Modification avec succés  ### \n");

*/





//*******************************   Fonction Ajouter Capteur *******************************



/*
Capteur c;
printf("\n Saisie du reference du capteur: ");
scanf("%s",c.ref);
printf("\n Saisie du typeDeCapteur: ");
scanf("%s",c.typeDeCapteur);
printf("\n Saisie du marque: ");
scanf("%s",c.marque);
printf("\n Saisie du BI: ");
scanf("%s",c.BI);
printf("\n Saisie du BS: ");
scanf("%s",c.BS);
printf("\n Saisie du dateMiseEnOeuvre: ");
scanf("%s",c.dateMiseEnOeuvre);
printf("\n Saisie du etat: ");
scanf("%d",&c.etat);
AjouterCapteur(c);

printf(" ###  Ajout avec succés  ### \n");

*


//*******************************   Fonction Afficher Capteur ******************************* 


 

/*
Capteur c;
FILE *f=NULL;

f=fopen("/home/ala/Projects/SmartFarm/src/capteurs.txt","r+");

if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %d %s \n " ,c.typeDeCapteur,c.marque,c.BI,c.BS,c.dateMiseEnOeuvre,&c.etat,c.ref)!=EOF)
  
printf("*TypeCapteur :%s | *Marque :%s | *BI :%s | *BS :%s | *Date :%s | *Etat :%d | *Reference :%s  \n",c.typeDeCapteur,c.marque,c.BI,c.BS,c.dateMiseEnOeuvre,c.etat,c.ref);
fclose(f);
}


else 
{
printf("Impossible d'ouvrir le fichier");
}
*/


//********************************* Fonction Supprimer Capteur ******************************* 

/*
supprimerCapteur("8");

printf(" ###  Suppression  avec succés  ### \n");
*/

//*******************************  Fonction Modifier Capteur ******************************* 




/*
char ref1[30];
Capteur c;

printf("\n Saisie du reference du capteur a modifier: ");
scanf("%s",ref1);

printf("\n Saisie la nouvelle valeur du reference du capteur: ");
scanf("%s",c.ref);
printf("\n Saisie le nouveau  typeDeCapteur: ");
scanf("%s",c.typeDeCapteur);
printf("\n Saisie la nouvelle  marque: ");
scanf("%s",c.marque);
printf("\n Saisie la nouvelle  BI: ");
scanf("%s",c.BI);
printf("\n Saisie la nouvelle  BS: ");
scanf("%s",c.BS);
printf("\n Saisie la nouvelle  dateMiseEnOeuvre: ");
scanf("%s",c.dateMiseEnOeuvre);
printf("\n Saisie la nouvelle  etat: ");
scanf("%d",&c.etat);
ModifierCapteur(c,ref1);

printf(" ###  Modification avec succés  ### \n");


//*******************************  Fonction Chercher Capteur ******************************* 

/*
int find=0;
find=ChercherCapteur("1");
printf("%d",find);
*/










}
