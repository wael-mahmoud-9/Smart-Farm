#include "historiqueCapteur.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


enum   
{   
	REFE,
	REFCAP,
    VALEUR,
	DATEE,
	COLUMN,

};

enum
{
	BII,
	BSS,
	REFCAPP,
	TYPECAP,
	VALEURCAP,
	DATECAP,
	COLUMNSSS,
};
///////////////////////Séparation

void AjouterValeur(historiqueCapteur hc) {

FILE *f=NULL;

f=fopen("historiqueCapteur.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %d %d %d %d \n",hc.ref,hc.refCapteur,hc.valeur,hc.datePreleveemnt.annee,hc.datePreleveemnt.mois,hc.datePreleveemnt.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");

}

///////////////////////Séparation


void SupprimerValeur(char ref[10]) {

FILE*f=NULL;
FILE*f1=NULL;
historiqueCapteur c;
f=fopen("historiqueCapteur.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)
{
if(strcmp(ref,c.ref)!=0)
{
fprintf(f1,"%s %s %d %d %d %d \n",c.ref,c.refCapteur,c.valeur,c.datePreleveemnt.annee,c.datePreleveemnt.mois,c.datePreleveemnt.jour);
}
}

fclose(f);
fclose(f1);
remove("historiqueCapteur.txt");
rename("ancien.txt","historiqueCapteur.txt");
}

void SupprimerValeur2(char ref[10]) {

FILE*f=NULL;
FILE*f1=NULL;
historiqueCapteur c;
f=fopen("historiqueCapteur.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)
{
if(strcmp(ref,c.refCapteur)!=0)
{
fprintf(f1,"%s %s %d %d %d %d \n",c.ref,c.refCapteur,c.valeur,c.datePreleveemnt.annee,c.datePreleveemnt.mois,c.datePreleveemnt.jour);
}
}

fclose(f);
fclose(f1);
remove("historiqueCapteur.txt");
rename("ancien.txt","historiqueCapteur.txt");
}


///////////////////////Séparation



void ModifierValeur( historiqueCapteur hc , char ref[30]) {

SupprimerValeur(ref);
AjouterValeur(hc);

}


///////////////////////Séparation

void AfficherHistorique(GtkWidget *liste) {


GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char val[30];
	char refCap[30];
	char jour[30];
	char mois[30];
	char annee[30];
	
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Réf Capteur",renderer, "text",REFCAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date prélèvement",renderer, "text",DATEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("historiqueCapteur.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("historiqueCapteur.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s \n " ,ref,refCap,val,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		
		gtk_list_store_append (store,&iter);

		
		gtk_list_store_set (store, &iter, REFE,ref,  REFCAP,refCap, VALEUR,val, DATEE,dateComp ,-1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}

///////////////////////Séparation
void ChercherValeur (GtkWidget *liste, char refe[30]) 
{

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char val[30];
	char refCap[30];
	char jour[30];
	char mois[30];
	char annee[30];
	
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REFE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		renderer = gtk_cell_renderer_text_new ();

		column = gtk_tree_view_column_new_with_attributes("Réf Capteur",renderer, "text",REFCAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date prélèvement",renderer, "text",DATEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("historiqueCapteur.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("historiqueCapteur.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s \n " ,ref,refCap,val,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		if(strcmp(refe,ref)==0 || strcmp(refe,val)==0 || strcmp(refe,annee)==0 || strcmp(refe,refCap)==0 )
		{
		gtk_list_store_append (store,&iter);

		
		gtk_list_store_set (store, &iter, REFE,ref, REFCAP,refCap, VALEUR,val, DATEE,dateComp ,-1 );
		
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}


void fichierRef() {

FILE*f=NULL;
FILE*f1=NULL;
Capteur c;
f=fopen("capteurs.txt","r");
f1=fopen("reference.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF)
{

fprintf(f1,"%s \n",c.ref);

}

fclose(f);
fclose(f1);

}



void fichierRef1() {

FILE*f=NULL;
FILE*f1=NULL;
historiqueCapteur c;
f=fopen("historiqueCapteur.txt","r");
f1=fopen("reference1.txt","w+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)
{

fprintf(f1,"%s \n",c.ref);

}

fclose(f);
fclose(f1);

}



//*************************************






//*************************************


void AfficherAlarmante(GtkWidget *liste) {


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	
	char refCap[30];
	char val[30];
	char bi[30];
	char bs[30];
	char type[30];
	char annee[30];
	char mois[30];
	char jour[30];
	char dateComp[30];
	
	
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REFCAPP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPECAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEURCAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BI",renderer, "text",BII, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BS",renderer, "text",BSS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date prelevement",renderer, "text",DATECAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNSSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("fichierTestAlaramante.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("fichierTestAlaramante.txt","r");
			while (fscanf(f,"%s %s %s %s %s %s %s %s \n " ,refCap,type,val,bi,bs,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	     strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);

		gtk_list_store_append (store,&iter);

		
		gtk_list_store_set (store, &iter, REFCAPP,refCap, TYPECAP,type, VALEURCAP,val,  BII,bi ,BSS,bs ,  DATECAP,dateComp, 			-1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}

}
}













