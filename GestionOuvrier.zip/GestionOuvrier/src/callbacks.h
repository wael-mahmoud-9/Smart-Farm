#include <gtk/gtk.h>


void
RedirectToAdd                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AddOuvrier                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SuppOuvrier                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectToUpdate                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
Refresh                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
REdirectToAfficher                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderCombo                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirChamps                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
UpdateOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
ModifOuvrier                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ChercherOuvrier                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
BackFromUpdateOuv                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AddAbsence                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AbsOui                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
AbsNon                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
ValiderRefAbs                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
GoToAbs                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemoveAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SearchAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RefreshAbs                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ResirectAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackFromAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackFromUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RetourOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
OuiUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
NonUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
UpdateAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
CalculerTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
