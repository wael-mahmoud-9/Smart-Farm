#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ouvrier.c"
#include "absence.c"


int choix;
int x=0;
GtkWidget *afficher,*treeview ,*ajouter,*update;



int is_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}


int existe(char ver[30]) {
FILE *f;
f = fopen("ouvrier.txt","r");
int find=0;
char id[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,id)!=EOF)
{
if(strcmp(ver,id)==0)
find=1;
}
}
else
printf("erreur \n");
return find;
}


void
RedirectToAdd                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	gtk_widget_hide (ajouter);
	afficher = create_AjoutOuvrier();
	gtk_widget_show (afficher);
	

}


void
AddOuvrier                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	Ouvrier p;
	GtkWidget *identifiant,*nom,*prenom,*tel,*fonction,*annee, *mois, *jour,*annee1, *mois1, *jour1 ;
	char ver[30];

	identifiant=lookup_widget(objet_graphique,"entry4");
	nom=lookup_widget(objet_graphique,"entry2");
	prenom=lookup_widget(objet_graphique,"entry3");
	tel=lookup_widget(objet_graphique, "entry5");
	fonction=lookup_widget(objet_graphique, "combobox1");
	jour=lookup_widget(objet_graphique, "spinbutton1");
	mois=lookup_widget(objet_graphique, "spinbutton2");
	annee=lookup_widget(objet_graphique, "spinbutton3");
	jour1=lookup_widget(objet_graphique, "spinbutton4");
	mois1=lookup_widget(objet_graphique, "spinbutton5");
	annee1=lookup_widget(objet_graphique, "spinbutton6");



	//gtk_entry_set_max_length(tel,8);
	strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(p.tel,gtk_entry_get_text(GTK_ENTRY(tel)));
	strcpy(p.fonction,gtk_combo_box_get_active_text(GTK_COMBO_BOX(fonction)));
	
	p.dateEmbauche.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateEmbauche.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateEmbauche.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.dateNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
	p.dateNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
	p.dateNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));



	if((p.dateEmbauche.jour >= 32) || (p.dateEmbauche.mois >= 13) ||  (p.dateEmbauche.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label22");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {

if((p.dateNaissance.jour >= 32) || (p.dateNaissance.mois >= 13) ||  (p.dateNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label19");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {



	AjouterOuvrier(p);

	ajouter=lookup_widget(objet_graphique,"AjoutOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListOuvrier(treeview);


}


}}



void
SuppOuvrier                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	

	
        
        p=lookup_widget(objet_graphique,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           

           supprimerOuvrier(id);

	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListOuvrier(treeview);
	
        }
           
	
	
	

}


void
RedirectToUpdate                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	gtk_widget_hide (ajouter);
	afficher = create_UpdateOuvrier();
	gtk_widget_show (afficher);

}


void
Refresh                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"AfficherOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListOuvrier(treeview);

}


void
REdirectToAfficher                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"AjoutOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListOuvrier(treeview);
	

}


void
ValiderCombo                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox2");
	btn=lookup_widget(objet_graphique,"button8");
	gtk_widget_set_sensitive ( btn, FALSE);//disable button
	fichierRef();
	
	char id[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,id)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(id));
	}
	fclose(f);
	remove("reference.txt");

}


void
RemplirChamps                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *ref,*nom,*prenom,*tel,*fonction,*jour,*mois,*annee,*jour1,*mois1,*annee1,*identifiant;
	
	identifiant=lookup_widget(objet_graphique,"combobox2");
	nom=lookup_widget(objet_graphique,"entry6");
	prenom=lookup_widget(objet_graphique,"entry7");
	tel=lookup_widget(objet_graphique,"entry8");
	fonction=lookup_widget(objet_graphique,"combobox3");

	jour=lookup_widget(objet_graphique,"spinbutton7");
	mois=lookup_widget(objet_graphique,"spinbutton8");
	annee=lookup_widget(objet_graphique,"spinbutton9");

	jour1=lookup_widget(objet_graphique,"spinbutton10");
	mois1=lookup_widget(objet_graphique,"spinbutton11");
	annee1=lookup_widget(objet_graphique,"spinbutton12");
	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));	
	Ouvrier c;
	FILE *f=NULL;
	f = fopen("ouvrier.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n" ,c.id,c.nom,c.prenom,c.tel
,c.fonction,&c.dateEmbauche.annee,&c.dateEmbauche.mois,&c.dateEmbauche.jour,&c.dateNaissance.annee
,&c.dateNaissance.mois,&c.dateNaissance.jour)!=EOF)

	{
	if(strcmp(var,c.id)==0)
	{
	//gtk_entry_set_text (ref,t.ref);
	gtk_entry_set_text (nom,c.nom);
	gtk_entry_set_text (prenom,c.prenom);
	gtk_entry_set_text (tel,c.tel);
	
	
	gtk_spin_button_set_value (annee, c.dateEmbauche.annee);
	gtk_spin_button_set_value (mois, c.dateEmbauche.mois);
	gtk_spin_button_set_value (jour, c.dateEmbauche.jour);

	gtk_spin_button_set_value (annee1, c.dateNaissance.annee);
	gtk_spin_button_set_value (mois1, c.dateNaissance.mois);
	gtk_spin_button_set_value (jour1, c.dateNaissance.jour);

	}

	
	}
	}
	fclose(f);

}


void
UpdateOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
}



void
ModifOuvrier                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	Ouvrier p;
	GtkWidget *identifiant,*nom,*prenom,*tel,*jour, *mois, *annee, *fonction,*jour1, *mois1, *annee1 ;
	char ver[30];

	
	identifiant=lookup_widget(objet_graphique,"combobox2");
	nom=lookup_widget(objet_graphique,"entry6");
	prenom=lookup_widget(objet_graphique,"entry7");
	tel=lookup_widget(objet_graphique, "entry8");
	fonction=lookup_widget(objet_graphique, "combobox3");

	jour=lookup_widget(objet_graphique, "spinbutton7");
	mois=lookup_widget(objet_graphique, "spinbutton8");
	annee=lookup_widget(objet_graphique, "spinbutton9");

	jour1=lookup_widget(objet_graphique, "spinbutton10");
	mois1=lookup_widget(objet_graphique, "spinbutton11");
	annee1=lookup_widget(objet_graphique, "spinbutton12");

	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	

	
	strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(p.tel,gtk_entry_get_text(GTK_ENTRY(tel)));

	strcpy(p.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	strcpy(p.fonction,gtk_combo_box_get_active_text(GTK_COMBO_BOX(fonction)));
	
	p.dateEmbauche.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateEmbauche.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateEmbauche.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.dateNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
	p.dateNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
	p.dateNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));


	if((p.dateEmbauche.jour >= 32) || (p.dateEmbauche.mois >= 13) ||  (p.dateEmbauche.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label32");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {

if((p.dateNaissance.jour >= 32) || (p.dateNaissance.mois >= 13) ||  (p.dateNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label34");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierOuvrier(p,ver);

	update=lookup_widget(objet_graphique,"UpdateOuvrier");
	gtk_widget_hide (update);
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListOuvrier(treeview);

	
	
	


}
}



}


void
ChercherOuvrier                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry1") ;
	w1=lookup_widget(objet_graphique,"AfficherOuvrier");
	
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	ChercherOuv(treeview,ss);
	
}




void
BackFromUpdateOuv                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"UpdateOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListOuvrier(treeview);

}


void
AddAbsence                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	Absence p;
	GtkWidget *identifiant,*idOuv,*annee, *mois, *jour;
	char ver[30];

	idOuv=lookup_widget(objet_graphique,"combobox4");
	identifiant=lookup_widget(objet_graphique,"entry10");
	
	
	jour=lookup_widget(objet_graphique, "spinbutton13");
	mois=lookup_widget(objet_graphique, "spinbutton14");
	annee=lookup_widget(objet_graphique, "spinbutton15");
	



	

	//gtk_entry_set_max_length(tel,8);
	strcpy(p.idOuvrier,gtk_combo_box_get_active_text(GTK_COMBO_BOX(idOuv)));
	strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	
	if(choix==0)
	{
	strcpy(p.abs,"Present");
	}
	if(choix==1)
	{
	strcpy(p.abs,"Absent");
	}
	
	p.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	



	

if((p.date.jour >= 32) || (p.date.mois >= 13) ||  (p.date.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label44");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {



	AjouterAbsence(p);

	ajouter=lookup_widget(objet_graphique,"AjoutAbscence");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherListAbsence(treeview);






}

	

}


void
AbsOui                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if( gtk_toggle_button_get_active(togglebutton)) {
choix=1;
}

}


void
AbsNon                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)) {
choix=0;
}

}


void
ValiderRefAbs                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox4");
	btn=lookup_widget(objet_graphique,"button13");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char id[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,id)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(id));
	}
	fclose(f);
	remove("reference.txt");

}


void
GoToAbs                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherListAbsence(treeview);

}


void
RemoveAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	

	
        
        p=lookup_widget(objet_graphique,"treeview2");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           

           supprimerAbsence(id);
	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherListAbsence(treeview);
	
        }
           
	
	
	

}


void
SearchAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry9") ;
	w1=lookup_widget(objet_graphique,"AfficherAbs");
	
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview2") ;
	ChercherAbsence(treeview,ss);
	

}


void
RedirectUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_ModifierAbs();
	gtk_widget_show (afficher);

}


void
RefreshAbs                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherListAbsence(treeview);
	

}


void
ResirectAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AjoutAbscence();
	gtk_widget_show (afficher);

}


void
BackFromAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	ajouter=lookup_widget(objet_graphique,"AjoutAbscence");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherListAbsence(treeview);

}


void
BackFromUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"ModifierAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherListAbsence(treeview);

}


void
RetourOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListOuvrier(treeview);

}


void
ValiderUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*idOuv,*btn;
	idOuv=lookup_widget(objet_graphique,"combobox6");
	combo=lookup_widget(objet_graphique,"combobox5");
	btn=lookup_widget(objet_graphique,"button15");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef1();
	
	char id[10];
	
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,id)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(idOuv),(id));
	}
	fclose(f);
	remove("reference.txt");

	

}


void
RemplirUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *jour,*mois,*annee,*identifiant,*idOuv,*oui,*non;
	
	identifiant=lookup_widget(objet_graphique,"combobox6");
	idOuv=lookup_widget(objet_graphique,"combobox5");
	

	jour=lookup_widget(objet_graphique,"spinbutton16");
	mois=lookup_widget(objet_graphique,"spinbutton17");
	annee=lookup_widget(objet_graphique,"spinbutton18");
	oui=lookup_widget(objet_graphique,"checkbutton3");
	non=lookup_widget(objet_graphique,"checkbutton4");

	
	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));	
	Absence c;
	FILE *f=NULL;
	f = fopen("absence.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %s %d %d %d \n" ,c.id,c.idOuvrier,c.abs,&c.date.annee,&c.date.mois,&c.date.jour)!=EOF)

	{
	if(strcmp(var,c.id)==0)
	{

	gtk_combo_box_append_text(idOuv,c.idOuvrier);
	gtk_spin_button_set_value (annee, c.date.annee);
	gtk_spin_button_set_value (mois, c.date.mois);
	gtk_spin_button_set_value (jour, c.date.jour);

	

	

	}
	}
	}
	fclose(f);


}


void
OuiUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	
if( gtk_toggle_button_get_active(togglebutton)) {
x=1;
}

}


void
NonUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	
if( gtk_toggle_button_get_active(togglebutton)) {
x=0;
}

}


void
UpdateAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	Absence p;
	GtkWidget *identifiant,*idOuv,*annee, *mois, *jour;
	char ver[30];

	identifiant=lookup_widget(objet_graphique,"combobox6");
	idOuv=lookup_widget(objet_graphique,"combobox5");
	
	
	jour=lookup_widget(objet_graphique, "spinbutton16");
	mois=lookup_widget(objet_graphique, "spinbutton17");
	annee=lookup_widget(objet_graphique, "spinbutton18");
	



	

	//gtk_entry_set_max_length(tel,8);
	strcpy(p.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	strcpy(p.idOuvrier,gtk_combo_box_get_active_text(GTK_COMBO_BOX(idOuv)));
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	
	if(x==0)
	{
	strcpy(p.abs,"Present");
	}
	if(x==1)
	{
	strcpy(p.abs,"Absent");
	}
	
	p.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	



	

if((p.date.jour >= 32) || (p.date.mois >= 13) ||  (p.date.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label44");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {



	ModifierAbsence(p,ver);

	ajouter=lookup_widget(objet_graphique,"ModifierAbs");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview2") ;
	AfficherListAbsence(treeview);






}

}


void
RedirectTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	afficher = create_TauxAbs();
	gtk_widget_show (afficher);
	

}


void
CalculerTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *anne, *moiss,*pInfo;
	int annee;
	int mois;
	float taux=0;
	

	
	
	
	
	moiss=lookup_widget(objet_graphique, "spinbutton19");
	anne=lookup_widget(objet_graphique, "spinbutton20");

	annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anne));
	mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moiss));
if((mois >= 13) ||  (annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label76");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

	

else {
taux = CalculeTaux(annee,mois);
char tt[10];
sprintf(tt,"%.2f",taux);
		
pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
GTK_DIALOG_MODAL,
GTK_MESSAGE_INFO,
GTK_BUTTONS_OK,
"Le taux d'absentéisme est : %s %%",tt);
gtk_dialog_run(GTK_DIALOG(pInfo));
gtk_widget_destroy(pInfo);

}	

	

	

}

