
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "intergration.h"

//////////////////////////WAEL////////////////////////////////////

enum 
{
	EANNEE,
	EPMIN,
	EPMAX,
	EPTOT,
	COLUMNSS, 
};


/* Fonction Ajouter */

void ajouter_don(donnee x)
{

FILE *f=NULL;

f=fopen("annee.txt","a");
fprintf(f,"%d %d %d %d\n",x.annee,x.pmin,x.pmax,x.ptot);


fclose(f);

}

/* Fonction Modifier */

void modifier_don(char sh1[20],char sh2[20],char sh3[20],char sh4[20], char *g)
{
FILE*f=NULL;
FILE*f1=NULL;

char ch1[25];
char ch2[25];
char ch3[25];
char ch4[25];
f=fopen("annee.txt","r");
f1=fopen("Nouveau.txt","w+");
while(fscanf(f,"%s %s %s %s\n",ch1,ch2,ch3,ch4)!=EOF)
{
if(strcmp(g,ch1)!=0)
fprintf(f1,"%s %s %s %s\n",ch1,ch2,ch3,ch4);
else 
fprintf(f1,"%s %s %s %s\n",sh1,sh2,sh3,sh4);
}
fclose(f);
fclose(f1);

remove("annee.txt");
rename("Nouveau.txt","annee.txt");
}

/* Fonction Supprimer */

void supprimer_don(char *g)
{

FILE*f=NULL;
FILE*f1=NULL;

char ch1[10];
char ch2[10];
char ch3[10];
char ch4[10];
f=fopen("annee.txt","r");
f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s\n",ch1,ch2,ch3,ch4)!=EOF)
{

if(strcmp(ch1,g)!=0)
fprintf(f1,"%s %s %s %s\n",ch1,ch2,ch3,ch4);
}
fclose(f);
fclose(f1);
remove("annee.txt");
rename("ancien.txt","annee.txt");
}

/* Fonction Afficher */

void afficher_don(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;



	char annee[30];
	char pmin[30];
	char pmax[30];
	char ptot[30];

	store=NULL;
	FILE *f=NULL;
	
	store= gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Année", renderer , "text" , EANNEE , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Précipitaion minimale", renderer , "text" , EPMIN , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Précipitaion maximale", renderer , "text" , EPMAX , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Précipitaion Totale", renderer , "text" , EPTOT , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	}
	store=gtk_list_store_new (COLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("annee.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f=fopen("annee.txt","a+");
		while(fscanf(f,"%s %s %s %s\n",annee,pmin,pmax,ptot)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, EANNEE, annee, EPMIN, pmin, EPMAX, pmax, EPTOT, ptot, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
		}


	
}
/* Fonction calul*/
int calcule (int x,int y)
{
int g;
g=x-y;
if(g<=0)
printf("Erreur");
else 
return g;
}


enum 
{
	EID,
	EMARQUE,
	ETYPE,
	EETAT,
	EPRIX,
	EDISPO,
	COLUMNS, 
};


/* Fonction Ajouter */

void ajouter_eq(equipement x)
{

FILE *f=NULL;

f=fopen("Equipements.txt","a");
fprintf(f,"%s %s %s %s %s %s\n",x.id,x.marque,x.type,x.etat,x.prix,x.dispo);


fclose(f);

}


/* Fonction Modifier */

void modifier_eq(equipement x, char *id)
{
FILE*f=NULL;
FILE*f1=NULL;
equipement e;
f=fopen("Equipements.txt","r");
f1=fopen("Nouveau.txt","w+");
while(fscanf(f,"%s %s %s %s %s %s\n",e.id,e.marque,e.type,e.etat,e.prix,e.dispo)!=EOF)
{
if(strcmp(id,e.id)!=0)
fprintf(f1,"%s %s %s %s %s %s\n",e.id,e.marque,e.type,e.etat,e.prix,e.dispo);
else 
fprintf(f1,"%s %s %s %s %s %s\n",x.id,x.marque,x.type,x.etat,x.prix,x.dispo);
}
fclose(f);
fclose(f1);

remove("Equipements.txt");
rename("Nouveau.txt","Equipements.txt");
}


/* Fonction Supprimer */

void supprimer_eq(char*id)
{

FILE*f=NULL;
FILE*f1=NULL;
equipement x ;
f=fopen("Equipements.txt","r");

f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %s %s\n",x.id,x.marque,x.type,x.etat,x.prix,x.dispo)!=EOF)
{
if(strcmp(id,x.id)!=0 )
fprintf(f1,"%s %s %s %s %s %s\n",x.id,x.marque,x.type,x.etat,x.prix,x.dispo);
}
fclose(f);
fclose(f1);
remove("Equipements.txt");
rename("ancien.txt","Equipements.txt");
}

/* Fonction Afficher */

void afficher_eq(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;



	char id[50];
	char marque[50];
	char type[50];
	char etat[50];
	char prix[50];	
	char dispo[50];

	store=NULL;
	FILE *f=NULL;
	
	store= gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("ID", renderer , "text" , EID , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Marque", renderer , "text" , EMARQUE , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type", renderer , "text" , ETYPE , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Etat", renderer , "text" , EETAT , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Prix", renderer , "text" , EPRIX , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Disponibilité", renderer , "text" , EDISPO , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("Equipements.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f=fopen("Equipements.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s\n",id,marque,type,etat,prix,dispo)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter, EID, id, EMARQUE, marque, ETYPE, type, EETAT, etat, EPRIX, prix, EDISPO, dispo, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
		}


	
}
 

/* Fonction Rechercher */

void rechercher_eq(GtkWidget *liste,char id1[30])
{
FILE *f=NULL;
equipement c;

while(fscanf(f,"%s %s %s %s %s %s\n",c.id,c.marque,c.type,c.etat,c.prix,c.dispo)!=EOF)
{
if (strcmp(id1,c.id)==0)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;



	char id[50];
	char marque[50];
	char type[50];
	char etat[50];
	char prix[50];	
	char dispo[50];

	store=NULL;
	FILE *f=NULL;
	
	store= gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("ID", renderer , "text" , EID , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Marque", renderer , "text" , EMARQUE , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Type", renderer , "text" , ETYPE , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Etat", renderer , "text" , EETAT , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Prix", renderer , "text" , EPRIX , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Disponibilité", renderer , "text" , EDISPO , NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
		f=fopen("Equipements.txt","r");
	while(fscanf(f,"%s %s %s %s %s %s\n",id,marque,type,etat,prix,dispo)!=EOF)
		{
			gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, EID, c.id, EMARQUE, c.marque, ETYPE, c.type, EETAT, c.etat, EPRIX, c.prix, EDISPO, c.dispo, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
		}

}
}
/* Fonction de verification */ 

int vide(GtkWidget *entry)
{
char ch2[30];

strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(ch2,"")==0)
return 0;
else
return 1;
}

/*
int exist(char ver[30]) 
{
FILE *f;
f = fopen("Equipements.txt","r");
int trouve=0;
char ref[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,ref)!=EOF)
{
if(strcmp(ver,ref)==0)
trouve=1;
}
}
else
printf("erreur \n");
return trouve;
}
*/


////////////////////////////FIN WAEL ////////////////////////////////////////////



////////////////////////////////integration////////////////////////////////////

void ajouter_ad(admin a)
{
FILE *f=NULL;

f=fopen("admins.txt","a");
fprintf(f,"%s %s \n",a.username,a.password);


fclose(f);
}

int verifier(char e1[30],char e2[30])
{
FILE *f=NULL;
f=fopen("admins.txt","r");
int u;
admin a;

while(fscanf(f,"%s %s \n",a.username,a.password)!=EOF)
{
printf("%s \n",a.username);
printf("%s \n",a.password);
if( (strcmp(a.username,e1)==0) && (strcmp(a.password,e2)==0) )
{
u=1;
}
else 
u=0;
return u;
}


}
/////////////////////////////FIN Integration ////////////////////////////


////////////////////////////////DHIA ////////////////////////////////////
enum   
{       ID,
        NOM,
	PRENOM,
	TEL,
	FONCTION,
        DATE,
	DATE1,
	COLUMNSD,
	
};



void AjouterOuvrier(Ouvrier c)
{

FILE *f=NULL;

f=fopen("ouvrier.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %s %s %s %d %d %d %d %d %d \n",c.id,c.nom,c.prenom,c.tel,c.fonction,c.dateEmbauche.annee,c.dateEmbauche.mois,c.dateEmbauche.jour,
c.dateNaissance.annee,c.dateNaissance.mois,c.dateNaissance.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
}




void AfficherListOuvrier(GtkWidget *liste) {

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char id[30];
	char nom[30];
	char prenom[30];
	char tel[30];
	char fonction[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char jour1[30];
	char mois1[30];
	char annee1[30];

	char dateComp[30];
	char dateComp1[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prenom",renderer, "text",PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Tel",renderer, "text",TEL, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Fonction",renderer, "text",FONCTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date embauche",renderer, "text",DATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date naissance",renderer, "text",DATE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNSD, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING
		, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("ouvrier.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("ouvrier.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n " ,id,nom,prenom,tel,fonction,annee,mois,jour,annee1,mois1,jour1)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);

		 strcpy(dateComp1,annee1);
	         strcat(dateComp1,"-");
		 strcat(dateComp1,mois1);
 	 	 strcat(dateComp1,"-");
		 strcat(dateComp1,jour1);
		
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, ID,id, NOM,nom, PRENOM,prenom, TEL,tel, FONCTION,fonction ,DATE,dateComp, DATE1,dateComp1, 			-1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}

}



void supprimerOuvrier(char id[30]){

FILE*f=NULL;
FILE*f1=NULL;
Ouvrier c;
f=fopen("ouvrier.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n" ,c.id,c.nom,c.prenom,c.tel
,c.fonction,&c.dateEmbauche.annee,&c.dateEmbauche.mois,&c.dateEmbauche.jour,&c.dateNaissance.annee
,&c.dateNaissance.mois,&c.dateNaissance.jour)!=EOF)
{
if(strcmp(id,c.id)!=0)
{
fprintf(f1,"%s %s %s %s %s %d %d %d %d %d %d \n",c.id,c.nom,c.prenom,c.tel,c.fonction,c.dateEmbauche.annee,c.dateEmbauche.mois,c.dateEmbauche.jour,
c.dateNaissance.annee,c.dateNaissance.mois,c.dateNaissance.jour);
}
}

fclose(f);
fclose(f1);
remove("ouvrier.txt");
rename("ancien.txt","ouvrier.txt");
}


void fichierRef() {

FILE*f=NULL;
FILE*f1=NULL;
Ouvrier c;
f=fopen("ouvrier.txt","r");
f1=fopen("reference.txt","w+");
while (fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n" ,c.id,c.nom,c.prenom,c.tel
,c.fonction,&c.dateEmbauche.annee,&c.dateEmbauche.mois,&c.dateEmbauche.jour,&c.dateNaissance.annee
,&c.dateNaissance.mois,&c.dateNaissance.jour)!=EOF)
{

fprintf(f1,"%s \n",c.id);

}

fclose(f);
fclose(f1);

}



void ModifierOuvrier(Ouvrier c , char id[30]) {

supprimerOuvrier(id);
AjouterOuvrier(c);

}


void ChercherOuv (GtkWidget *liste, char id1[30]) {

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char id[30];
	char nom[30];
	char prenom[30];
	char tel[30];
	char fonction[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char jour1[30];
	char mois1[30];
	char annee1[30];

	char dateComp[30];
	char dateComp1[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prenom",renderer, "text",PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Tel",renderer, "text",TEL, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Fonction",renderer, "text",FONCTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date embauche",renderer, "text",DATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date naissance",renderer, "text",DATE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNSD, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING
		, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("ouvrier.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("ouvrier.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n " ,id,nom,prenom,tel,fonction,annee,mois,jour,annee1,mois1,jour1)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);

		 strcpy(dateComp1,annee1);
	         strcat(dateComp1,"-");
		 strcat(dateComp1,mois1);
 	 	 strcat(dateComp1,"-");
		 strcat(dateComp1,jour1);
if(strcmp(id1,id)==0 || strcmp(id1,nom)==0  || strcmp(id1,prenom)==0 || strcmp(id1,tel)==0 || strcmp(id1,annee)==0
|| strcmp(id1,dateComp)==0 || strcmp(id1,annee1)==0 || strcmp(id1,dateComp1)==0) 
		{
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, ID,id, NOM,nom, PRENOM,prenom, TEL,tel, FONCTION,fonction ,DATE,dateComp, DATE1,dateComp1, 			-1 );
		
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}

}



enum   
{       IDD,
	IDOUV,
        ABSENCE,
        DATEE,
	DCOLUMNSS,
	
};




void AjouterAbsence(Absence c)
{

FILE *f=NULL;

f=fopen("absence.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %s %d %d %d \n",c.id,c.idOuvrier,c.abs,c.date.annee,c.date.mois,c.date.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
}


//***********************//

void AfficherListAbsence(GtkWidget *liste) {

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char id[30];
	char idOuv[30];
	char abs[30];
	char jour[30];
	char mois[30];
	char annee[30];
	

	char dateComp[30];
	
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDD, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("ID ouvrier",renderer, "text",IDOUV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Absentéisme",renderer, "text",ABSENCE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		
		store=gtk_list_store_new (DCOLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("absence.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("absence.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s \n" ,id,idOuv,abs,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);

		 
		
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, IDD,id, IDOUV,idOuv, ABSENCE,abs, DATEE,dateComp, -1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}

}


//**************************************


void supprimerAbsence(char id[30]){

FILE*f=NULL;
FILE*f1=NULL;
Absence c;
f=fopen("absence.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d \n",c.id,c.idOuvrier,c.abs,&c.date.annee,&c.date.mois,&c.date.jour)!=EOF)
{
if(strcmp(id,c.id)!=0)
{
fprintf(f1,"%s %s %s %d %d %d \n",c.id,c.idOuvrier,c.abs,c.date.annee,c.date.mois,c.date.jour);
}
}

fclose(f);
fclose(f1);
remove("absence.txt");
rename("ancien.txt","absence.txt");
}

//**************************************



void ChercherAbsence(GtkWidget *liste, char id1[30]) {

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char id[30];
	char idOuv[30];
	char abs[30];
	
	char jour[30];
	char mois[30];
	char annee[30];
	

	char dateComp[30];
	
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDD, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("ID ouvrier",renderer, "text",IDOUV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Absentéisme",renderer, "text",ABSENCE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		
		store=gtk_list_store_new (DCOLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("absence.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("absence.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s \n" ,id,idOuv,abs,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
if(strcmp(id1,id)==0 || strcmp(id1,idOuv)==0 || strcmp(id1,abs)==0  || strcmp(id1,annee)==0 || strcmp(id1,mois)==0 || strcmp(id1,jour)==0 || strcmp(id1,dateComp)==0 ) 
		{
		 
		
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, IDD,id, IDOUV,idOuv, ABSENCE,abs, DATEE,dateComp, -1 );
		
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}

}


//*********************************************



void fichierRef1() {

FILE*f=NULL;
FILE*f1=NULL;
Absence c;
f=fopen("absence.txt","r");
f1=fopen("reference.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d \n" ,c.id,c.idOuvrier,c.abs,&c.date.annee,&c.date.mois,&c.date.jour)!=EOF)
{

fprintf(f1,"%s \n",c.id);

}

fclose(f);
fclose(f1);

}

//**********************************************


void ModifierAbsence(Absence c , char id[30]) {

supprimerAbsence(id);
AjouterAbsence(c);

}

//**********************************************


int CalculerNbrOuvrier(int annee, int mois) {

FILE *f=NULL;
int nbr=0;
Ouvrier c;
f=fopen("ouvrier.txt","r");
while (fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n" ,c.id,c.nom,c.prenom,c.tel
,c.fonction,&c.dateEmbauche.annee,&c.dateEmbauche.mois,&c.dateEmbauche.jour,&c.dateNaissance.annee
,&c.dateNaissance.mois,&c.dateNaissance.jour)!=EOF)
{

if( annee == c.dateEmbauche.annee &&  mois == c.dateEmbauche.mois )
nbr=nbr+1; 

}

fclose(f);
return nbr;

}


//**********************************************

float CalculerNbrOuvrierAbsent(int annee, int mois) {

FILE *f=NULL;
float nbr=0;
Absence c;
f=fopen("absence.txt","r");
while (fscanf(f,"%s %s %s %d %d %d \n" ,c.id,c.idOuvrier,c.abs,&c.date.annee,&c.date.mois,&c.date.jour)!=EOF)
{

if( (annee == c.date.annee) &&  (mois == c.date.mois) && (strcmp(c.abs,"Absent")==0 ) )
nbr=nbr+1; 

}

fclose(f);
return nbr;

}


//***********************************************


float CalculeTaux(int annee, int mois)

{
FILE *f=NULL;
int nbr=0;
float nbrA=0;
float taux=0;
nbr=CalculerNbrOuvrier(annee,mois);
nbrA=CalculerNbrOuvrierAbsent(annee,mois);
if(nbr == 0 || nbrA == 0 ) {
taux =0;
}
else {
taux = (nbrA/nbr)*100;
}
f=fopen("test.txt","a+");

if(f!=NULL)
{

fprintf(f,"%d %.2f %.2f \n",nbr,nbrA,taux);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
return taux;
}


///////////Fin dhia/////////////////////////

/////////////////////////Khalil ////////////////////////////

enum   
{       NOMS,
        PRENOMS,
	CIN,
	TELEPHONE,
	FONCTIONS,
        JOUR,
	MOIS,
	ANNEE,
	SEXE,
	COLUMNSSSS,
	TAUX,
	NBPR,
	NBABS,
};




void ajouter_employe(employe e)
{
  FILE *f;
  FILE *g;
  f=fopen("employes.txt","a+");
  if(f!=NULL) 
{
  fprintf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,e.jour,e.mois,e.annee,e.sexe);
  fclose(f);
}
  g=fopen("absence.txt","a+");
  if(g!=NULL) 
{
  fprintf(g,"%s %s %s 0 0 0\n",e.nom,e.prenom,e.cin);
  fclose(g);
}

}

///////////////////////////////////////////////////////////////////
int supprimer_employe(employe e,char cin[15])
{
    FILE*f;
    FILE*c;
    absence a;
    int suppri=0;
    f=fopen("employes.txt","r+");
    c=fopen("tmp.txt","w+");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,&e.jour,&e.mois,&e.annee,e.sexe)!=EOF)
        {

            if ((strcmp(e.cin,cin)!=0))
            {               
               fprintf(c,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,e.jour,e.mois,e.annee,e.sexe);              
            }
            else
            {
              suppri=1;
            }
        }
    }
fclose(f);
fclose(c);
remove("employes.txt");
rename("tmp.txt","employes.txt");
    f=fopen("absence.txt","r+");
    c=fopen("tmp.txt","w+");
if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
        {

            if ((strcmp(a.cin,cin)!=0))
            {               
               fprintf(c,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,a.taux,a.nbabs,a.nbpr);              
            }
        }
    }
fclose(f);
fclose(c);
remove("absence.txt");
rename("tmp.txt","absence.txt");
return suppri;
}
/////////////////////////////////////////////////////////


void afficher_employe(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char nom[30];
	char prenom[30];
	char cin[15];
	char telephone[15];
	char fonction[30];
	char jour[5];
	char mois[5];
	char annee[6];
	char sexe[30];
	char nbabs[5];
	char nbpr[5];
	char taux[5];
	char jj[30];
	char mm[30];
	char aa[30];

	store=NULL;

	FILE *f;
	FILE *c;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOMS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prenom",renderer, "text",PRENOMS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin",renderer, "text",CIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Telephone",renderer, "text",TELEPHONE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Fonction",renderer, "text",FONCTIONS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


 		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour",renderer, "text",JOUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mois",renderer, "text",MOIS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Annee",renderer, "text",ANNEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nombre d'absence",renderer, "text",NBABS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nombre de presence",renderer, "text",NBPR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Taux d'absence",renderer, "text",TAUX, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		

		store=gtk_list_store_new (COLUMNSSSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("employes.txt","r");
		
		c = fopen("absence.txt","r");
		if((f==NULL)&&(c==NULL))
		{
			return;
		}
		else
		{
			f = fopen("employes.txt","a+");
			c = fopen("absence.txt","a+");
			while((fscanf(f,"%s %s %s %s %s %s %s %s %s\n",nom,prenom,cin,telephone,fonction,jour,mois,annee,sexe)!=EOF)&&(fscanf(c,"%s %s %s %s %s %s\n",jj,mm,aa,taux,nbabs,nbpr)!=EOF))
			{
		gtk_list_store_append(store,&iter);
		gtk_list_store_set (store, &iter, NOMS, nom, PRENOMS, prenom, CIN, cin, TELEPHONE, telephone, FONCTIONS, fonction, JOUR, jour, MOIS, mois, ANNEE, annee, SEXE, 	sexe, NBABS, nbabs, NBPR, nbpr, TAUX, taux, -1 );
			}
			fclose(f);
			fclose(c);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
 		g_object_unref(store);
}
}
}
////////////////////////////////////////////////////////////////////

void modifier_employe(employe e1)
{
    FILE*f;
    FILE*g;
    employe e;
    absence a;
    char cin[9];
    f=fopen("employes.txt","r");
    g=fopen("tmp.txt","a+");

    
    if(f!=NULL)
    { if(g!=NULL)
    { 
        while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,&e.jour,&e.mois,&e.annee,e.sexe)!=EOF)
        {
		printf("\n %s \n",e1.cin);
            if(strcmp(e.cin,e1.cin)!=0)
            {
                fprintf(g,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,e.jour,e.mois,e.annee,e.sexe);	
			printf("\n ok \n");

            }
            else
            { printf("\n ok1 \n");



                fprintf(g,"%s %s %s %s %s %d %d %d %s\n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.fonction,e1.jour,e1.mois,e1.annee,e1.sexe);
            }
        }
        fclose(f);
        fclose(g);
remove("employes.txt");
rename("tmp.txt","employes.txt");
    }
    }
    
    f=fopen("absence.txt","r");
    g=fopen("tmp.txt","a+");

    
    if(f!=NULL)
    { if(g!=NULL)
    { 
        while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
        {
		printf("\n %s \n",e1.cin);
            if(strcmp(a.cin,e1.cin)!=0)
            {
                fprintf(g,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,a.taux,a.nbabs,a.nbpr);	
			printf("\n ok \n");

            }
            else
            { printf("\n ok1 \n");



                fprintf(g,"%s %s %s %d %d %d\n",e1.nom,e1.prenom,e1.cin,a.taux,a.nbabs,a.nbpr);
            }
        }
        fclose(f);
        fclose(g);
remove("absence.txt");
rename("tmp.txt","absence.txt");

    }}

}
////////////////////////////////////////////////////////////////////
employe rechercher (char cin[30])
{
    FILE*f;

employe e;
    

    f=fopen("employes.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,&e.jour,&e.mois,&e.annee,e.sexe)!=EOF)
    {
        if((strcmp(e.cin,cin)==0))
        {
	 printf("ok \n");
	return e;
fclose(f);
	}
        
		strcpy(e.nom,"erreur");
		strcpy(e.prenom,"erreur");
		strcpy(e.cin,"erreur");
               
                
                

			    
    }
	
    fclose (f);}
    return e;

}



///////////////////////////////////////////////////
absence recherch (char cin[30])
{
    FILE*f;

absence a;
    

    f=fopen("absence.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
    {
        if((strcmp(a.cin,cin)==0))
        {
	 printf("ok \n");
	
	fclose(f);
	return a;
	}
        
		a.taux=-99;
                
        }
	
    fclose (f);}
    return a;

}
/////////////////////////////////////////////////////////
void modifier_abs(absence a1)
{
    FILE*f;
    FILE*g;
    absence a;
    char cin[9];
    f=fopen("absence.txt","r");
    g=fopen("tmp.txt","a+");

    
    if(f!=NULL)
    { if(g!=NULL)
    { 
        while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
        {
		printf("\n %s \n",a1.cin);
            if(strcmp(a.cin,a1.cin)!=0)
            {
                fprintf(g,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,a.taux,a.nbabs,a.nbpr);	
			printf("\n oki \n");

            }
            else
            { printf("\n oki1 \n");



                fprintf(g,"%s %s %s %d %d %d\n",a1.nom,a1.prenom,a1.cin,a1.taux,a1.nbabs,a1.nbpr);
            }
        }
        fclose(f);
        fclose(g);
remove("absence.txt");
rename("tmp.txt","absence.txt");

    }}
}
//////////////////////////////////////////////////////
absence meilleur ()
{
    FILE*f;

absence a;
absence a1;
    int t=101;

    f=fopen("absence.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
    {
     if(a.taux < t)
        {
	 t=a.taux;
	 a1=a;
	}
                
    }
	
    fclose (f);}
    return a1;

}
/*
absence meilleur()
{
	FILE *f;
absence a;
absence a1;
int som=0;
    f=fopen("absence.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
	{
		if(a1.cin==a.cin)
			{ 
				a.taux=som++;
			}
	fclose(f);}

	if(a.taux<a1.taux)
		{ return a1.taux;}
	else {return a.taux;}
}
	
*/				
////////////////////////////FIN KHalil//////////////////////////////




//////////////////////////ALA////////////////////////////////////////



enum   
{       AREF1,
        ATYPE1,
	AMARQUE1,
	ABI1,
	ABS1,
        ADATE1,
	AETAT1,
	ACOLUMNS1,
	
};

///////////////////////Séparation


void AjouterCapteur(Capteur c)
{

FILE *f=NULL;

f=fopen("capteurs.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %s %d %d %d %d %d %d \n",c.ref,c.typeDeCapteur,c.marque,c.BI,c.BS,c.etat,c.dateMiseEnOeuvre.annee,
c.dateMiseEnOeuvre.mois,c.dateMiseEnOeuvre.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
}

///////////////////////Séparation



void supprimerCapteur(char ref[30]){

FILE*f=NULL;
FILE*f1=NULL;
Capteur c;
f=fopen("capteurs.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF)
{
if(strcmp(ref,c.ref)!=0)
{
fprintf(f1,"%s %s %s %d %d %d %d %d %d \n",c.ref,c.typeDeCapteur,c.marque,c.BI,c.BS,c.etat,c.dateMiseEnOeuvre.annee,
c.dateMiseEnOeuvre.mois,c.dateMiseEnOeuvre.jour);
}
}

fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("ancien.txt","capteurs.txt");
}

///////////////////////Séparation

void ModifierCapteur(Capteur c , char ref[30]) {

supprimerCapteur(ref);
AjouterCapteur(c);

}


///////////////////////Séparation


void ChercherCapteur ( GtkWidget *liste, char refe[30]) {

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char type[30];
	char marque[30];
	char bi[30];
	char bs[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char etat[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",AREF1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Type de capteur",renderer, "text",ATYPE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",AMARQUE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Etat",renderer, "text",AETAT1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BI",renderer, "text",ABI1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BS",renderer, "text",ABS1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",ADATE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (ACOLUMNS1, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING
		, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("capteurs.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("capteurs.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s %s %s \n " ,ref,type,marque,bi,bs,etat,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
if(strcmp(refe,ref)==0 || strcmp(refe,type)==0  || strcmp(refe,marque)==0 || strcmp(refe,bi)==0 || strcmp(refe,bs)==0
|| strcmp(refe,annee)==0 ) 			
		
		{
		gtk_list_store_append (store,&iter);

		if(strcmp(etat,"3")==0)
		{
		gtk_list_store_set (store, &iter, AREF1,ref, ATYPE1,type, AMARQUE1,marque, ABI1,bi ,ABS1,bs , AETAT1,"OFF", ADATE1,dateComp, -1 );
		}if(strcmp(etat,"1")==0)
		{
		gtk_list_store_set (store, &iter, AREF1,ref, ATYPE1,type, AMARQUE1,marque, ABI1,bi ,ABS1,bs , AETAT1,"ON", ADATE1,dateComp, -1 );
		}if(strcmp(etat,"2")==0)
		{
		gtk_list_store_set (store, &iter, AREF1,ref, ATYPE1,type, AMARQUE1,marque, ABI1,bi ,ABS1,bs , AETAT1,"En panne", ADATE1,dateComp,-1 );
		}
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


int is_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}


int existe(char ver[30]) {
FILE *f;
f = fopen("capteurs.txt","r");
int find=0;
char ref[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,ref)!=EOF)
{
if(strcmp(ver,ref)==0)
find=1;
}
}
else
printf("erreur \n");
return find;
}



}

void AfficherListCapteures(GtkWidget *liste) {


GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char type[30];
	char marque[30];
	char bi[30];
	char bs[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char etat[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",AREF1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Type de capteur",renderer, "text",ATYPE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",AMARQUE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Etat",renderer, "text",AETAT1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BI",renderer, "text",ABI1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BS",renderer, "text",ABS1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",ADATE1, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (ACOLUMNS1, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING
		, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("capteurs.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("capteurs.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s %s %s \n " ,ref,type,marque,bi,bs,etat,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		
		gtk_list_store_append (store,&iter);

		if(strcmp(etat,"3")==0)
		{
		gtk_list_store_set (store, &iter, AREF1,ref, ATYPE1,type, AMARQUE1,marque, ABI1,bi ,ABS1,bs , AETAT1,"OFF", ADATE1,dateComp, -1 );
		}if(strcmp(etat,"1")==0)
		{
		gtk_list_store_set (store, &iter, AREF1,ref, ATYPE1,type, AMARQUE1,marque, ABI1,bi ,ABS1,bs , AETAT1,"ON", ADATE1,dateComp, -1 );
		}if(strcmp(etat,"2")==0)
		{
		gtk_list_store_set (store, &iter, AREF1,ref, ATYPE1,type, AMARQUE1,marque, ABI1,bi ,ABS1,bs , AETAT1,"En panne", ADATE1,dateComp, 			-1 );
		}
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}

}

/*
void extractVersTableau()
{
    
    Capteur tab[500][5000];
	Capteur c;
    //char c;
    int k, i=0, j=0; // k indice de lecture des lignes, i nombre de lignes, j indice caractère 
 
    FILE *file = fopen("capteurs.txt","r");
   // FILE *f = fopen("equipement.txt","r");
    //FILE *f1 = fopen("marrque.txt","a+");
    if (file == NULL)
       printf("erreur");
 /*
    //c = fgetc(file); // lecture du 1er caractère du fichier 
    while (fscanf(file,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF) // Tant qu'on est pas en fin de fichier 
    {
       
            strcpy(tab[i][j].ref,c.ref);
			strcpy(tab[i][j].typeDeCapteur,c.typeDeCapteur);
			strcpy(tab[i][j].marque,c.marque);
			tab[i][j].BI = c.BI;
			tab[i][j].BS = c.BS;
			tab[i][j].etat = c.etat;
			tab[i][j].dateMiseEnOeuvre.annee = c.dateMiseEnOeuvre.annee;
			tab[i][j].dateMiseEnOeuvre.mois = c.dateMiseEnOeuvre.mois;
			tab[i][j].dateMiseEnOeuvre.jour = c.dateMiseEnOeuvre.jour;
			 // affectation du caractère à l'index j 
            j++; // index suivant pour le caractère suivant 
            
        
 
        //c.dateMiseEnOeuvre.jour = fgetc(file); // lecture du prochaine caractère 
        
		for (k=0; k<i; k++)
		printf("%s\n", tab[k]);
    }
 */
    //fclose(file);
 
   /*
    if (file == NULL)
        exit(EXIT_FAILURE);
    char ref[30];
    char marque[30];
    char type[30];
    int dispo;
    int jour;
    int mois;
    int annee;
    while (fscanf(f,"%s %s %s %d %d %d %d \n " ,ref,marque,type,&dispo,&annee,&mois,&jour)!=EOF)
    {
        for (k=0; k<i; k++)
        {
            char test[30];
            strcpy(test,tab[k]);
            //printf("%s\n", ref);
            
            if(atoi(test) == atoi(ref) )
            fprintf(f1,"%s \n",marque);
            
        }
    }
    fclose(f);
    fclose(f1);
*/
//}
//

int compteDonnees()
{
 char lignes[200];
 int nbLignes=0;
 
 FILE * fp;
 
 // ouverture fichier et verif
 if ((fp=fopen ("capteurs.txt","r")) == NULL)
 printf("Impossible d'ouvrir le fichier données en lecture\n");
 
 // lecture ligne par ligne
 // while (!=feof(fp))
 while(fgets(lignes,200,fp)!= NULL){
 nbLignes++;
 //fscanf(fp,"%s %s %d %d %d\n",ligne);
 }
 
 fclose (fp);
 return nbLignes;
}


void lirefscanf ()
{
  
  int i,nbLignes;
 
  FILE * fp;
  FILE * f;
  FILE * f1;
 
 nbLignes=compteDonnees();
 printf("%d\n", nbLignes);
 
 Capteur  sauveDonnee[nbLignes];
 // ouverture fichier et verif
 fp=fopen ("capteurs.txt","r");
 if (fp == NULL)
 printf("Impossible d'ouvrir le fichier données en lecture\n");
 
 for(i=0; i<nbLignes;i++)
 {
  fscanf(fp,"%s %s %s %d %d %d %d %d %d \n",sauveDonnee[i].ref, sauveDonnee[i].typeDeCapteur, 
  sauveDonnee[i].marque, &sauveDonnee[i].BI, &sauveDonnee[i].BS, &sauveDonnee[i].etat, &sauveDonnee[i].dateMiseEnOeuvre.annee, &sauveDonnee[i].dateMiseEnOeuvre.mois, &sauveDonnee[i].dateMiseEnOeuvre.jour);
 }
 
 fclose (fp);
 char ref[30];
 char refCapteur[30];
 int valeur=0;
 int annee=0;
 int mois=0;
 int jour=0;
f=fopen ("historiqueCapteur.txt","r");
f1=fopen ("fichierTestAlaramante.txt","a+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,ref,refCapteur,&valeur,&annee,&mois,&jour)!=EOF)
	 {
	 //printf("premier boucle \n");
	 
	for(i=0; i<nbLignes;i++)
 	{
	 //printf("%s %s\n", sauveDonnee[i].typeDeCapteur,sauveDonnee[i].marque);
	// printf("deuxieme boucle \n");
	 if((strcmp(refCapteur,sauveDonnee[i].ref)==0) && ((valeur >= sauveDonnee[i].BS) || ( sauveDonnee[i].BI >= valeur)))
	 {
		 printf("%s %d %d\n", sauveDonnee[i].ref,sauveDonnee[i].BI,sauveDonnee[i].BS);
		 fprintf(f1,"%s %s %d %d %d %d %d %d \n",refCapteur,sauveDonnee[i].typeDeCapteur,valeur,sauveDonnee[i].BI,sauveDonnee[i].BS,annee,mois,jour);
	 }
	 }
 }
 fclose(f);
 fclose(f1);

}

enum   
{   
	REFE,
	REFCAP,
    	VALEUR,
	AADATEE,
	COLUMN,

};

enum
{
	BII,
	BSS,
	REFCAPP,
	TYPECAP,
	VALEURCAP,
	DATECAP,
	COLUMNSSS,
};
///////////////////////Séparation

void AjouterValeur(historiqueCapteur hc) {

FILE *f=NULL;

f=fopen("historiqueCapteur.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %d %d %d %d \n",hc.ref,hc.refCapteur,hc.valeur,hc.datePreleveemnt.annee,hc.datePreleveemnt.mois,hc.datePreleveemnt.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");

}

///////////////////////Séparation


void SupprimerValeur(char ref[10]) {

FILE*f=NULL;
FILE*f1=NULL;
historiqueCapteur c;
f=fopen("historiqueCapteur.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)
{
if(strcmp(ref,c.ref)!=0)
{
fprintf(f1,"%s %s %d %d %d %d \n",c.ref,c.refCapteur,c.valeur,c.datePreleveemnt.annee,c.datePreleveemnt.mois,c.datePreleveemnt.jour);
}
}

fclose(f);
fclose(f1);
remove("historiqueCapteur.txt");
rename("ancien.txt","historiqueCapteur.txt");
}

void SupprimerValeur2(char ref[10]) {

FILE*f=NULL;
FILE*f1=NULL;
historiqueCapteur c;
f=fopen("historiqueCapteur.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)
{
if(strcmp(ref,c.refCapteur)!=0)
{
fprintf(f1,"%s %s %d %d %d %d \n",c.ref,c.refCapteur,c.valeur,c.datePreleveemnt.annee,c.datePreleveemnt.mois,c.datePreleveemnt.jour);
}
}

fclose(f);
fclose(f1);
remove("historiqueCapteur.txt");
rename("ancien.txt","historiqueCapteur.txt");
}


///////////////////////Séparation



void ModifierValeur( historiqueCapteur hc , char ref[30]) {

SupprimerValeur(ref);
AjouterValeur(hc);

}


///////////////////////Séparation

void AfficherHistorique(GtkWidget *liste) {


GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char val[30];
	char refCap[30];
	char jour[30];
	char mois[30];
	char annee[30];
	
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REFE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Réf Capteur",renderer, "text",REFCAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date prélèvement",renderer, "text",AADATEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("historiqueCapteur.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("historiqueCapteur.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s \n " ,ref,refCap,val,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		
		gtk_list_store_append (store,&iter);

		
		gtk_list_store_set (store, &iter, REFE,ref,  REFCAP,refCap, VALEUR,val, AADATEE,dateComp ,-1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}

///////////////////////Séparation
void ChercherValeur (GtkWidget *liste, char refe[30]) 
{

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char val[30];
	char refCap[30];
	char jour[30];
	char mois[30];
	char annee[30];
	
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REFE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		renderer = gtk_cell_renderer_text_new ();

		column = gtk_tree_view_column_new_with_attributes("Réf Capteur",renderer, "text",REFCAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date prélèvement",renderer, "text",AADATEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("historiqueCapteur.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("historiqueCapteur.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s \n " ,ref,refCap,val,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		if(strcmp(refe,ref)==0 || strcmp(refe,val)==0 || strcmp(refe,annee)==0 || strcmp(refe,refCap)==0 )
		{
		gtk_list_store_append (store,&iter);

		
		gtk_list_store_set (store, &iter, REFE,ref, REFCAP,refCap, VALEUR,val, DATEE,dateComp ,-1 );
		
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}


void afichierRef() {

FILE*f=NULL;
FILE*f1=NULL;
Capteur c;
f=fopen("capteurs.txt","r");
f1=fopen("reference.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF)
{

fprintf(f1,"%s \n",c.ref);

}

fclose(f);
fclose(f1);

}



void afichierRef1() {

FILE*f=NULL;
FILE*f1=NULL;
historiqueCapteur c;
f=fopen("historiqueCapteur.txt","r");
f1=fopen("reference1.txt","w+");
while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)
{

fprintf(f1,"%s \n",c.ref);

}

fclose(f);
fclose(f1);

}



//*************************************






//*************************************


void AfficherAlarmante(GtkWidget *liste) {


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	
	char refCap[30];
	char val[30];
	char bi[30];
	char bs[30];
	char type[30];
	char annee[30];
	char mois[30];
	char jour[30];
	char dateComp[30];
	
	
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REFCAPP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPECAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEURCAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BI",renderer, "text",BII, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("BS",renderer, "text",BSS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date prelevement",renderer, "text",DATECAP, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNSSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("fichierTestAlaramante.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("fichierTestAlaramante.txt","r");
			while (fscanf(f,"%s %s %s %s %s %s %s %s \n " ,refCap,type,val,bi,bs,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	     strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);

		gtk_list_store_append (store,&iter);

		
		gtk_list_store_set (store, &iter, REFCAPP,refCap, TYPECAP,type, VALEURCAP,val,  BII,bi ,BSS,bs ,  DATECAP,dateComp, 			-1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}

}
}
//////////////////////WASSIM /////////////////////////////////////


enum   
{       wREF,
        wRACE,
	wCOULEUR,
	wPOID,
        wDATE,
	wCOLUMNS,
	
};


void AjouterTroupeau(Troupeau c)
{

FILE *f=NULL;

f=fopen("troupeau.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %s %d %d %d %d \n",c.ref,c.race,c.couleur,c.poid_a_la_naissance,
c.dateDeNaissance.annee,c.dateDeNaissance.mois,c.dateDeNaissance.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
}



void AfficherListTroupeau(GtkWidget *liste) {


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char race[30];
	char couleur[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char poid[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",wREF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Race",renderer, "text",wRACE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Couleur",renderer, "text",wCOULEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Poid",renderer, "text",wPOID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",wDATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (wCOLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("troupeau.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("troupeau.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s \n " ,ref,race,couleur,poid,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, wREF,ref, wRACE,race, wCOULEUR,couleur,  wPOID,poid, wDATE,dateComp, -1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}


void supprimerTroupeau(char ref[30]){

FILE*f=NULL;
FILE*f1=NULL;
Troupeau c;
f=fopen("troupeau.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d \n" ,c.ref,c.race,c.couleur,&c.poid_a_la_naissance
,&c.dateDeNaissance.annee,&c.dateDeNaissance.mois,&c.dateDeNaissance.jour)!=EOF)
{
if(strcmp(ref,c.ref)!=0)
{
fprintf(f1,"%s %s %s %d %d %d %d \n",c.ref,c.race,c.couleur,c.poid_a_la_naissance,
c.dateDeNaissance.annee,c.dateDeNaissance.mois,c.dateDeNaissance.jour);
}
}

fclose(f);
fclose(f1);
remove("troupeau.txt");
rename("ancien.txt","troupeau.txt");
}





void ChercherTroupeau (GtkWidget *liste, char refe[30]) 
{
	
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char race[30];
	char couleur[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char poid[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",wREF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Race",renderer, "text",wRACE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Couleur",renderer, "text",wCOULEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Poid",renderer, "text",wPOID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",wDATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (wCOLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("troupeau.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("troupeau.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s \n " ,ref,race,couleur,poid,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
    if(strcmp(refe,ref)==0 || strcmp(refe,race)==0  || strcmp(refe,couleur)==0 || strcmp(refe,poid)==0 || strcmp(refe,annee)==0
|| strcmp(refe,dateComp)==0) 			
		
		{
		
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, wREF,ref, wRACE,race, wCOULEUR,couleur,  wPOID,poid, wDATE,dateComp, -1 );
		
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}


void ModifierTroupeau(Troupeau c , char ref[30]) {

supprimerTroupeau(ref);
AjouterTroupeau(c);

}




void wwfichierRef() {

FILE*f=NULL;
FILE*f1=NULL;
Troupeau c;
f=fopen("troupeau.txt","r");
f1=fopen("reference.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d \n" ,c.ref,c.race,c.couleur,&c.poid_a_la_naissance
,&c.dateDeNaissance.annee,&c.dateDeNaissance.mois,&c.dateDeNaissance.jour)!=EOF)
{

fprintf(f1,"%s \n",c.ref);

}

fclose(f);
fclose(f1);

}



//nombre troupeaux
void nbtoupeaux ()
{
int ca=0;
int  p=0; int  v=0;  int m=0 ;
Troupeau c;
FILE*f;
f=fopen("troupeau.txt","r");
while(fscanf(f,"%s %s %s %d %d %d %d \n" ,c.ref,c.race,c.couleur,&c.poid_a_la_naissance
,&c.dateDeNaissance.annee,&c.dateDeNaissance.mois,&c.dateDeNaissance.jour)!=EOF)
{
if(strcmp(c.race,"vache")==0)
{
v=v+1;
}
else if(strcmp(c.race,"poule")==0)
{
p=p+1;
}
else if(strcmp(c.race,"mouton")==0)
{
m=m+1;
}
else if(strcmp(c.race,"chevale")==0)
{
ca=ca+1;
}
}
}


///////////////////////////fin wassim /////////////////////////////////////////////
