#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "intergration.h"

#include <stdlib.h>
#include <unistd.h>

#include <string.h>


int x ;
int choix;
char tex1[30];
char tex2[30];


////////////WAEL/////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	GtkTreeIter iter;
	gchar *id;
	gchar *marque;
	gchar *type;
	gchar *etat;
	gchar *prix;
	gchar *dispo;
	equipement k;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path))
	{
	//obtention des valeurs de la ligne selectionee

	gtk_tree_model_get (GTK_LIST_STORE(model), &iter,0,&id,1,&marque,2,&type,3,&etat,4,&prix,5,&dispo, -1);
	//copie des valeurs dans la variable k de type equipement pour la passer  a la fonction de la supression
	strcpy(k.id,id);
	strcpy(k.marque,marque);
	strcpy(k.type,type);
	strcpy(k.etat,etat);
	strcpy(k.prix,prix);
	strcpy(k.dispo,dispo);
	
	//mise a jour de l'affichage de la treeview
	afficher_eq(treeview);
	}
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
	GtkWidget *ques;
	GtkWidget *afficher;

        gchar* id; //gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*
        

 ques =	gtk_message_dialog_new(GTK_WINDOW(afficher),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment \n supprimer cet équipement ?");

	switch (gtk_dialog_run(GTK_DIALOG(ques)))
	{
	case GTK_RESPONSE_YES:


        p=lookup_widget(objet,"treeview1");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_eq(id);// supprimer la ligne du fichier


	}

	gtk_widget_destroy(ques);
	break;

	case GTK_RESPONSE_NO:
	gtk_widget_destroy(ques);
	break;
}
}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj,*curr;
aj=lookup_widget(objet,"Gestion");
curr=create_Modifier();
gtk_widget_destroy(aj);
gtk_widget_show(curr);
}


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sid,*ec;

ec=lookup_widget(objet,"Gestion");
sid=lookup_widget(objet,"treeview1");
afficher_eq(sid);
}


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj,*curr;
aj=lookup_widget(objet,"Gestion");
curr=create_Ajouter();
gtk_widget_destroy(aj);
gtk_widget_show(curr);
}


void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
char ch1[30];
GtkWidget *rem,*tree,*tree1;

tree1=lookup_widget(objet,"Gestion");
rem=lookup_widget(objet,"cherche");


if((vide(rem)==0))
{
		GtkWidget *control=lookup_widget(objet,"label20");
                gtk_label_set_text(GTK_LABEL(control),"Veuillez saisir l'id à rechercher");
}
else 
{
rem=lookup_widget(objet,"cherche");
tree=lookup_widget(objet,"treeview1");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(rem)));
rechercher_eq(tree,ch1);

}
}


void
on_ok_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data)
{
//char tr[30];

equipement h;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
GtkWidget *curr,*t;
GtkWidget *get;


curr=lookup_widget(objet,"Ajouter");

input1=lookup_widget(objet,"id1");
input2=lookup_widget(objet,"marque1");
input3=lookup_widget(objet,"type1");
input4=lookup_widget(objet,"etat1");
input5=lookup_widget(objet,"prix1");
input6=lookup_widget(objet,"radiobutton1");
input7=lookup_widget(objet,"radiobutton2");

if((vide(input1)==0)||(vide(input2)==0)||(vide(input3)==0)||(vide(input4)==0)||(vide(input5)==0)) 
{
		GtkWidget *cont=lookup_widget(objet,"ctrl");
                gtk_label_set_text(GTK_LABEL(cont),"Veuillez fournir toutes les informations nécessaires");

}
/*
else 
{
	strcpy(tr,gtk_entry_get_text(GTK_ENTRY(input1)));
	if(exist(tr)==1)
	{
	GtkWidget *ex=lookup_widget(objet,"exs");
        gtk_label_set_text(GTK_LABEL(ex),"Cet id existe dèja dans le fichier ");
	}
	*/
else 
{
	strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(h.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(h.type,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(h.etat,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(h.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
	if(x==1)
	{
	strcpy(tex1,"Disponible");
	strcpy(h.dispo,tex1);
	}
	else
	{
	strcpy(tex2,"Nondisponible");
	strcpy(h.dispo,tex2);	
	}
	}
	
	ajouter_eq(h);
	gtk_widget_destroy(curr);
	t=create_Gestion();
	gtk_widget_show(t);
	get=create_Msg();
	gtk_widget_show(get);
	
}
//}


void
on_non_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *re,*fe;
fe=lookup_widget(objet,"Ajouter");
re=create_Gestion();
gtk_widget_destroy(fe);
gtk_widget_show(re);
}


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

char fh[30];
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7;
GtkWidget *cur,*t,*com;
GtkWidget *get;
equipement k;

cur=lookup_widget(objet,"Modifier");

com=lookup_widget(objet,"combobox1");


input1=lookup_widget(objet,"mod_id1");
input2=lookup_widget(objet,"mod_marque1");
input3=lookup_widget(objet,"mod_type1");
input4=lookup_widget(objet,"mod_etat1");
input5=lookup_widget(objet,"mod_prix1");
input6=lookup_widget(objet,"radiobuttonmod1");
input7=lookup_widget(objet,"radiobuttonmod2");

if((vide(input1)==0)||(vide(input2)==0)||(vide(input3)==0)||(vide(input4)==0)||(vide(input5)==0)) 
{
		GtkWidget *contr=lookup_widget(objet,"ctrl1");
                gtk_label_set_text(GTK_LABEL(contr),"Veuillez fournir toutes les informations nécessaires");

}
else 
{
	strcpy(fh,gtk_combo_box_get_active_text(GTK_COMBO_BOX(com)));	
	strcpy(k.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(k.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(k.type,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(k.etat,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(k.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
	if(x==3)
	{
	strcpy(tex1,"Disponible");
	strcpy(k.dispo,tex1);
	}
	else
	{
	strcpy(tex2,"Nondisponible");
	strcpy(k.dispo,tex2);	
	}
	}
	
	modifier_eq(k,fh);
	
	gtk_widget_destroy(cur);
	t=create_Gestion();
	gtk_widget_show(t);
	get=create_Msg();
	gtk_widget_show(get);
}


void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *re,*fe;
fe=lookup_widget(objet,"Modifier");
re=create_Gestion();
gtk_widget_destroy(fe);
gtk_widget_show(re);
}


void
on_back_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *re,*fe;
fe=lookup_widget(objet,"Gestion");
re=create_Home();
gtk_widget_destroy(fe);
gtk_widget_show(re);
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
//dispo
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
//Non dispo
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}


void
on_charge_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE *f=NULL;
equipement e;
GtkWidget *combo,*tr;

f=fopen("Equipements.txt","r");
tr=lookup_widget(objet,"Modifier");
combo=lookup_widget(objet,"combobox1");
while(fscanf(f,"%s %s %s %s %s %s \n",e.id,e.marque,e.type,e.etat,e.prix,e.dispo)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX (combo),_(e.id));
}


}

void
on_radiobuttonmod2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
//Nondispo
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=4;
}
}



void
on_radiobuttonmod1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
//dispo
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=3;
}
}






void
on_consulter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *cur,*next;
cur=lookup_widget(objet,"Gestion");
next=create_Annee();
gtk_widget_destroy(cur);
gtk_widget_show(next);
}

void
on_treeview2_row_activated             (GtkTreeView     *treeview2,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *annee;
	gchar *pmin;
	gchar *pmax;
	gchar *ptot;
	
	donnee k;

	char ch1[30];
	char ch2[30];
	char ch3[30];
	char ch4[30];
	
	sprintf(ch1, "%d",k.annee);
	sprintf(ch2, "%d",k.pmin);
	sprintf(ch3, "%d",k.pmax);
	sprintf(ch4, "%d",k.ptot);
	GtkTreeModel *model = gtk_tree_view_get_model(treeview2);

	if(gtk_tree_model_get_iter(model, &iter, path))
	{
	//obtention des valeurs de la ligne selectionee

	gtk_tree_model_get (GTK_LIST_STORE(model), &iter,0,&annee,1,&pmin,2,&pmax,3,&ptot, -1);
	//copie des valeurs dans la variable k de type equipement pour la passer  a la fonction de la supression
	strcpy(ch1,annee);
	strcpy(ch2,pmin);
	strcpy(ch3,pmax);
	strcpy(ch4,ptot);

	
	//mise a jour de l'affichage de la treeview
	afficher_don(treeview2);
	}
}

void
on_recuperer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*FILE *f=NULL;
donnee t;
f=fopen("annee.txt","r");
int min,y;
int year,x;
fscanf(f,"%d %d %d %d",t.annee,t.pmin,t.pmax,t.ptot);
y=t.ptot;
year=t.annee;
while(fscanf(f,"%d %d %d %d\n",t.annee,t.pmin,t.pmax,t.ptot)!=EOF)
{
if(t.ptot<=y)
{
y=t.ptot;
year=t.annee;
}
else
{
min=t.ptot;
x=t.annee;
}
}
printf("%d",x);*/
}

void
on_display_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sid,*ec;

ec=lookup_widget(objet,"Annee");
sid=lookup_widget(objet,"treeview2");
afficher_don(sid);
}

void
on_add_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *go,*cut;
cut=lookup_widget(objet,"Annee");
go=create_Ajouter1();
gtk_widget_destroy(cut);
gtk_widget_show(go);
}

void
on_modify_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *go,*cut;
cut=lookup_widget(objet,"Annee");
go=create_Modifier1();
gtk_widget_destroy(cut);
gtk_widget_show(go);
}

void
on_delete_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
	GtkWidget *ques;
	GtkWidget *afficher;

        gchar *annee; //gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*
        

 ques =	gtk_message_dialog_new(GTK_WINDOW(afficher),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment \n supprimer les données de cette année ?");

	switch (gtk_dialog_run(GTK_DIALOG(ques)))
	{
	case GTK_RESPONSE_YES:


        p=lookup_widget(objet,"treeview2");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&annee,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_don(annee);// supprimer la ligne du fichier


	}

	gtk_widget_destroy(ques);
	break;

	case GTK_RESPONSE_NO:
	gtk_widget_destroy(ques);
	break;
}
}

void
on_back1_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ro,*fo;
ro=lookup_widget(objet,"Annee");
fo=create_Gestion();
gtk_widget_destroy(ro);
gtk_widget_show(fo);
}


void
on_Annuler1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *go,*cut;
cut=lookup_widget(objet,"Ajouter1");
go=create_Annee();
gtk_widget_destroy(cut);
gtk_widget_show(go);
}


void
on_annule_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *go,*cut;
cut=lookup_widget(objet,"Modifier1");
go=create_Annee();
gtk_widget_destroy(cut);
gtk_widget_show(go);
}


void
on_load_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

{
FILE *f=NULL;

GtkWidget *combot,*tr;
char c1[10];
char c2[10];
char c3[10];
char c4[10];
f=fopen("annee.txt","r");
tr=lookup_widget(objet,"Modifier1");
combot=lookup_widget(objet,"combobox2");
while(fscanf(f,"%s %s %s %s\n",c1,c2,c3,c4)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX (combot),_(c1));
}
}
}


void
on_valide_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fo,*new;
GtkWidget *input1,*input2,*input3;
GtkWidget *rot;
GtkWidget *get;
donnee k;
char x1[20];
char x2[20];
char x3[20];
char x4[20];
char fh[20];

rot=lookup_widget(objet,"combobox2");
fo=lookup_widget(objet,"Modifier1");
input1=lookup_widget(objet,"spinbutton2");
input2=lookup_widget(objet,"spinbuttonminim");
input3=lookup_widget(objet,"spinbuttonmaxim");

strcpy(fh,gtk_combo_box_get_active_text(GTK_COMBO_BOX(rot)));
k.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
k.pmin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
k.pmax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));
k.ptot=calcule(k.pmax,k.pmin);

sprintf(x1, "%d",k.annee);
sprintf(x2, "%d",k.pmin);
sprintf(x3, "%d",k.pmax);
sprintf(x4, "%d",k.ptot);
modifier_don(x1,x2,x3,x4,fh);

gtk_widget_destroy(fo);
new=create_Annee();
gtk_widget_show(new);
get=create_Msg();
gtk_widget_show(get);
}


void
on_valider1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *curr;
GtkWidget *input1,*input2,*input3;
GtkWidget *clo;
GtkWidget *get;

donnee h;
curr=lookup_widget(objet,"Ajouter1");
input1=lookup_widget(objet,"spinbuttonannee");
input2=lookup_widget(objet,"spinbuttonmini");
input3=lookup_widget(objet,"spinbuttonmaxi");


h.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
h.pmin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input2));
h.pmax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input3));

h.ptot=calcule(h.pmax,h.pmin);
ajouter_don(h);

clo=create_Annee();
gtk_widget_destroy(curr);
gtk_widget_show(clo);
get=create_Msg();
gtk_widget_show(get);
}

/////////////////////FIN WAEL////////////////////////////////

//////////////////INTERGRATION ////////////////////////////////
void
on_connexion_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2;
char ch1[20];
char ch2[20];
int p=0;
input1=lookup_widget(objet,"username1");
input2=lookup_widget(objet,"password1");

strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(ch2,gtk_entry_get_text(GTK_ENTRY(input2)));

p=verifier(ch1,ch2);
printf("%d \n",p);
//printf("%s \n",ch1);
//printf("%s \n",ch2);
if(p==1)
{
GtkWidget *tre,*tre1;
tre=lookup_widget(objet,"Login");
tre1=create_Home();
gtk_widget_hide(tre);
gtk_widget_show(tre1);
}
else 
{
GtkWidget *control=lookup_widget(objet,"labelinf");
gtk_label_set_text(GTK_LABEL(control),"Mot de passe et/ou username incorrect");
}
}


void
on_Inscrire_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*input2,*sss,*dd;

input=lookup_widget(objet,"entryuser");
input2=lookup_widget(objet,"entrypass");

char tr1[30];
char tr2[30];
strcpy(tr1,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(tr2,gtk_entry_get_text(GTK_ENTRY(input2)));
admin b;
if ( (strcmp(tr1,"")==0)||(strcmp(tr2,"")==0) )
{
GtkWidget *control=lookup_widget(objet,"control");
gtk_label_set_text(GTK_LABEL(control),"Champs manquants.");
}
else 
{
strcpy(b.username,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(b.password,gtk_entry_get_text(GTK_ENTRY(input2)));
ajouter_ad(b);
dd=lookup_widget(objet,"Inscription");
sss=create_Login();
gtk_widget_show(sss);
gtk_widget_hide(dd);
}

}

void
on_alleremploye_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1,*in2;
in1=lookup_widget(objet,"Home");
in2=create_gestionemploye();
gtk_widget_destroy(in1);
gtk_widget_show(in2);
}


void
on_allercapteur_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1;
in1=create_InterfaceAddCapteurAdmin();
gtk_widget_show(in1);
}


void
on_allerouvrier_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1,*in2;
in1=lookup_widget(objet,"Home");
in2=create_AfficherOuvrier();
gtk_widget_destroy(in1);
gtk_widget_show(in2);
}


void
on_allerequipement_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1,*in2;
in2=lookup_widget(objet,"Home");
in1=create_Gestion();
gtk_widget_destroy(in2);
gtk_widget_show(in1);
}


void
on_allertroupeaux_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1;
in1=create_InterfaceAfficherTroup();
gtk_widget_show(in1);
}


void
on_quit_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1;
in1=lookup_widget(objet,"Home");
gtk_widget_destroy(in1);
}


void
on_inscription_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *in1,*in2;
in1=lookup_widget(objet,"Login");
in2=create_Inscription();
gtk_widget_destroy(in1);
gtk_widget_show(in2);
}
//////////////////////////////////:FIN INTEG/////////////////////////////

////////////////////////dhia //////////////////////////////////
int choix;
int dh=0;
GtkWidget *afficher,*treeview ,*ajouter,*update;



int is_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}


int existe(char ver[30]) {
FILE *f;
f = fopen("ouvrier.txt","r");
int find=0;
char id[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,id)!=EOF)
{
if(strcmp(ver,id)==0)
find=1;
}
}
else
printf("erreur \n");
return find;
}


void
RedirectToAdd                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	gtk_widget_hide (ajouter);
	afficher = create_AjoutOuvrier();
	gtk_widget_show (afficher);
	

}


void
AddOuvrier                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	Ouvrier p;
	GtkWidget *identifiant,*nom,*prenom,*tel,*fonction,*annee, *mois, *jour,*annee1, *mois1, *jour1 ;
	char ver[30];

	identifiant=lookup_widget(objet_graphique,"entry4");
	nom=lookup_widget(objet_graphique,"entry2");
	prenom=lookup_widget(objet_graphique,"entry3");
	tel=lookup_widget(objet_graphique, "entry5");
	fonction=lookup_widget(objet_graphique, "combobox3");
	jour=lookup_widget(objet_graphique, "spinbutton3");
	mois=lookup_widget(objet_graphique, "spinbutton4");
	annee=lookup_widget(objet_graphique, "spinbutton5");
	jour1=lookup_widget(objet_graphique, "spinbutton6");
	mois1=lookup_widget(objet_graphique, "spinbutton7");
	annee1=lookup_widget(objet_graphique, "spinbutton8");



	//gtk_entry_set_max_length(tel,8);
	strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(p.tel,gtk_entry_get_text(GTK_ENTRY(tel)));
	strcpy(p.fonction,gtk_combo_box_get_active_text(GTK_COMBO_BOX(fonction)));
	
	p.dateEmbauche.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateEmbauche.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateEmbauche.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.dateNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
	p.dateNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
	p.dateNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));



	if((p.dateEmbauche.jour >= 32) || (p.dateEmbauche.mois >= 13) ||  (p.dateEmbauche.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label92");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {

if((p.dateNaissance.jour >= 32) || (p.dateNaissance.mois >= 13) ||  (p.dateNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label93");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {



	AjouterOuvrier(p);

	ajouter=lookup_widget(objet_graphique,"AjoutOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview3") ;
	AfficherListOuvrier(treeview);


}


}}



void
SuppOuvrier                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	

	
        
        p=lookup_widget(objet_graphique,"treeview3");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           

           supprimerOuvrier(id);

	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview3") ;
	AfficherListOuvrier(treeview);
	
        }
           
	
	
	

}


void
RedirectToUpdate                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	gtk_widget_hide (ajouter);
	afficher = create_UpdateOuvrier();
	gtk_widget_show (afficher);

}


void
Refresh                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"AfficherOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview3") ;
	AfficherListOuvrier(treeview);

}


void
REdirectToAfficher                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"AjoutOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview3") ;
	AfficherListOuvrier(treeview);
	

}


void
ValiderCombo                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox4");
	btn=lookup_widget(objet_graphique,"button8");
	gtk_widget_set_sensitive ( btn, FALSE);//disable button
	fichierRef();
	
	char id[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,id)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(id));
	}
	fclose(f);
	remove("reference.txt");

}


void
RemplirChamps                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *ref,*nom,*prenom,*tel,*fonction,*jour,*mois,*annee,*jour1,*mois1,*annee1,*identifiant;
	
	identifiant=lookup_widget(objet_graphique,"combobox4");
	nom=lookup_widget(objet_graphique,"entry6");
	prenom=lookup_widget(objet_graphique,"entry7");
	tel=lookup_widget(objet_graphique,"entry8");
	fonction=lookup_widget(objet_graphique,"combobox5");

	jour=lookup_widget(objet_graphique,"spinbutton9");
	mois=lookup_widget(objet_graphique,"spinbutton10");
	annee=lookup_widget(objet_graphique,"spinbutton11");

	jour1=lookup_widget(objet_graphique,"spinbutton12");
	mois1=lookup_widget(objet_graphique,"spinbutton13");
	annee1=lookup_widget(objet_graphique,"spinbutton14");
	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));	
	Ouvrier c;
	FILE *f=NULL;
	f = fopen("ouvrier.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n" ,c.id,c.nom,c.prenom,c.tel
,c.fonction,&c.dateEmbauche.annee,&c.dateEmbauche.mois,&c.dateEmbauche.jour,&c.dateNaissance.annee
,&c.dateNaissance.mois,&c.dateNaissance.jour)!=EOF)

	{
	if(strcmp(var,c.id)==0)
	{
	//gtk_entry_set_text (ref,t.ref);
	gtk_entry_set_text (nom,c.nom);
	gtk_entry_set_text (prenom,c.prenom);
	gtk_entry_set_text (tel,c.tel);
	
	
	gtk_spin_button_set_value (annee, c.dateEmbauche.annee);
	gtk_spin_button_set_value (mois, c.dateEmbauche.mois);
	gtk_spin_button_set_value (jour, c.dateEmbauche.jour);

	gtk_spin_button_set_value (annee1, c.dateNaissance.annee);
	gtk_spin_button_set_value (mois1, c.dateNaissance.mois);
	gtk_spin_button_set_value (jour1, c.dateNaissance.jour);

	}

	
	}
	}
	fclose(f);

}


void
UpdateOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
}



void
ModifOuvrier                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	Ouvrier p;
	GtkWidget *identifiant,*nom,*prenom,*tel,*jour, *mois, *annee, *fonction,*jour1, *mois1, *annee1 ;
	char ver[30];

	
	identifiant=lookup_widget(objet_graphique,"combobox4");
	nom=lookup_widget(objet_graphique,"entry6");
	prenom=lookup_widget(objet_graphique,"entry7");
	tel=lookup_widget(objet_graphique, "entry8");
	fonction=lookup_widget(objet_graphique, "combobox5");

	jour=lookup_widget(objet_graphique, "spinbutton9");
	mois=lookup_widget(objet_graphique, "spinbutton10");
	annee=lookup_widget(objet_graphique, "spinbutton11");

	jour1=lookup_widget(objet_graphique, "spinbutton12");
	mois1=lookup_widget(objet_graphique, "spinbutton13");
	annee1=lookup_widget(objet_graphique, "spinbutton14");

	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	

	
	strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(p.tel,gtk_entry_get_text(GTK_ENTRY(tel)));

	strcpy(p.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	strcpy(p.fonction,gtk_combo_box_get_active_text(GTK_COMBO_BOX(fonction)));
	
	p.dateEmbauche.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateEmbauche.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateEmbauche.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.dateNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
	p.dateNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
	p.dateNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));


	if((p.dateEmbauche.jour >= 32) || (p.dateEmbauche.mois >= 13) ||  (p.dateEmbauche.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label103");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {

if((p.dateNaissance.jour >= 32) || (p.dateNaissance.mois >= 13) ||  (p.dateNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label104");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierOuvrier(p,ver);

	update=lookup_widget(objet_graphique,"UpdateOuvrier");
	gtk_widget_hide (update);
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview3") ;
	AfficherListOuvrier(treeview);

	
	
	


}
}



}


void
ChercherOuvrier                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry1") ;
	w1=lookup_widget(objet_graphique,"AfficherOuvrier");
	
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview3") ;
	ChercherOuv(treeview,ss);
	
}




void
BackFromUpdateOuv                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"UpdateOuvrier");
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview3") ;
	AfficherListOuvrier(treeview);

}

void
GoToAbs                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	ajouter=lookup_widget(objet_graphique,"AfficherOuvrier");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	treeview = lookup_widget(afficher, "treeview4") ;
	AfficherListAbsence(treeview);

}

void
RemoveAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	

	
        
        p=lookup_widget(objet_graphique,"treeview4");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           

           supprimerAbsence(id);
	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview4") ;
	AfficherListAbsence(treeview);
	
        }
           
	
	
	

}


void
SearchAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry10") ;
	w1=lookup_widget(objet_graphique,"AfficherAbs");
	
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview4") ;
	ChercherAbsence(treeview,ss);
	

}


void
RedirectUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_ModifierAbs();
	gtk_widget_show (afficher);

}


void
RefreshAbs                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview4") ;
	AfficherListAbsence(treeview);
	

}


void
ResirectAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AjoutAbscence();
	gtk_widget_show (afficher);

}


void
BackFromAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	ajouter=lookup_widget(objet_graphique,"AjoutAbscence");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview4") ;
	AfficherListAbsence(treeview);

}


void
BackFromUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"ModifierAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview4") ;
	AfficherListAbsence(treeview);

}


void
RetourOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"AfficherAbs");
	gtk_widget_hide (ajouter);
	afficher = create_AfficherOuvrier();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview3") ;
	AfficherListOuvrier(treeview);

}


void
ValiderUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*idOuv,*btn;
	idOuv=lookup_widget(objet_graphique,"combobox7");
	combo=lookup_widget(objet_graphique,"combobox8");
	btn=lookup_widget(objet_graphique,"button15");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef1();
	
	char id[10];
	
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,id)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(idOuv),(id));
	}
	fclose(f);
	remove("reference.txt");

	

}


void
RemplirUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *jour,*mois,*annee,*identifiant,*idOuv,*oui,*non;
	
	identifiant=lookup_widget(objet_graphique,"combobox7");
	idOuv=lookup_widget(objet_graphique,"combobox8");
	

	jour=lookup_widget(objet_graphique,"spinbutton18");
	mois=lookup_widget(objet_graphique,"spinbutton19");
	annee=lookup_widget(objet_graphique,"spinbutton20");
	oui=lookup_widget(objet_graphique,"checkbutton3");
	non=lookup_widget(objet_graphique,"checkbutton4");

	
	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));	
	Absence c;
	FILE *f=NULL;
	f = fopen("absence.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %s %d %d %d \n" ,c.id,c.idOuvrier,c.abs,&c.date.annee,&c.date.mois,&c.date.jour)!=EOF)

	{
	if(strcmp(var,c.id)==0)
	{

	gtk_combo_box_append_text(idOuv,c.idOuvrier);
	gtk_spin_button_set_value (annee, c.date.annee);
	gtk_spin_button_set_value (mois, c.date.mois);
	gtk_spin_button_set_value (jour, c.date.jour);

	

	

	}
	}
	}
	fclose(f);


}


void
OuiUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	
if( gtk_toggle_button_get_active(togglebutton)) {
dh=1;
}

}


void
NonUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	
if( gtk_toggle_button_get_active(togglebutton)) {
dh=0;
}

}


void
UpdateAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	Absence p;
	GtkWidget *identifiant,*idOuv,*annee, *mois, *jour;
	char ver[30];

	identifiant=lookup_widget(objet_graphique,"combobox7");
	idOuv=lookup_widget(objet_graphique,"combobox8");
	
	
	jour=lookup_widget(objet_graphique, "spinbutton18");
	mois=lookup_widget(objet_graphique, "spinbutton19");
	annee=lookup_widget(objet_graphique, "spinbutton20");
	



	

	//gtk_entry_set_max_length(tel,8);
	strcpy(p.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	strcpy(p.idOuvrier,gtk_combo_box_get_active_text(GTK_COMBO_BOX(idOuv)));
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(identifiant)));
	
	if(dh==0)
	{
	strcpy(p.abs,"Present");
	}
	if(dh==1)
	{
	strcpy(p.abs,"Absent");
	}
	
	p.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	



	

if((p.date.jour >= 32) || (p.date.mois >= 13) ||  (p.date.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label118");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {



	ModifierAbsence(p,ver);

	ajouter=lookup_widget(objet_graphique,"ModifierAbs");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview4") ;
	AfficherListAbsence(treeview);






}

}


void
RedirectTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	afficher = create_TauxAbs();
	gtk_widget_show (afficher);
	

}


void
CalculerTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *anne, *moiss,*pInfo;
	int annee;
	int mois;
	float taux=0;
	

	
	
	
	
	moiss=lookup_widget(objet_graphique, "spinbutton21");
	anne=lookup_widget(objet_graphique, "spinbutton22");

	annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anne));
	mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moiss));
if((mois >= 13) ||  (annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label149");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

	

else {
taux = CalculeTaux(annee,mois);
char tt[10];
sprintf(tt,"%.2f",taux);
		
pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
GTK_DIALOG_MODAL,
GTK_MESSAGE_INFO,
GTK_BUTTONS_OK,
"Le taux d'absentéisme est : %s %%",tt);
gtk_dialog_run(GTK_DIALOG(pInfo));
gtk_widget_destroy(pInfo);

}	

	

	

}
void
ValiderRefAbs                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox6");
	btn=lookup_widget(objet_graphique,"button13");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char id[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,id)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(id));
	}
	fclose(f);
	remove("reference.txt");

}
void
AbsOui                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if( gtk_toggle_button_get_active(togglebutton)) {
choix=1;
}

}


void
AbsNon                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)) {
choix=0;
}

}
void
AddAbsence                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	Absence p;
	GtkWidget *identifiant,*idOuv,*annee, *mois, *jour;
	char ver[30];

	idOuv=lookup_widget(objet_graphique,"combobox6");
	identifiant=lookup_widget(objet_graphique,"entry9");
	
	
	jour=lookup_widget(objet_graphique, "spinbutton15");
	mois=lookup_widget(objet_graphique, "spinbutton16");
	annee=lookup_widget(objet_graphique, "spinbutton17");
	



	

	//gtk_entry_set_max_length(tel,8);
	strcpy(p.idOuvrier,gtk_combo_box_get_active_text(GTK_COMBO_BOX(idOuv)));
	strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	
	if(choix==0)
	{
	strcpy(p.abs,"Present");
	}
	if(choix==1)
	{
	strcpy(p.abs,"Absent");
	}
	
	p.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	



	

if((p.date.jour >= 32) || (p.date.mois >= 13) ||  (p.date.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label118");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide");
}

else {



	AjouterAbsence(p);

	ajouter=lookup_widget(objet_graphique,"AjoutAbscence");
	afficher = create_AfficherAbs();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview4") ;
	AfficherListAbsence(treeview);






}

	

}

/////////////Fin dhia////////////////////////////////////////

///////////////////////khalil ///////////////////////////////////

GtkWidget *gestionemploye;
GtkWidget *treeAFF;
GtkWidget *notebook1;
GtkWidget *output;


void
on_buttonAJ_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
employe e;

GtkWidget *nom, *prenom, *cin, *telephone,*fonction, *jour, *mois, *annee, *sexeh, *sexef;
GtkWidget *admin,*yt;

gestionemploye=lookup_widget(objet, "gestionemploye");

nom=lookup_widget(objet, "EN");
prenom=lookup_widget(objet, "EP");
cin=lookup_widget(objet, "ECI");
telephone=lookup_widget(objet, "entry14");
fonction=lookup_widget(objet, "ETAF");
jour=lookup_widget(objet, "spinbuttonJA");
mois=lookup_widget(objet, "spinbuttonMA");
annee=lookup_widget(objet, "spinbuttonAA");
sexeh=lookup_widget(objet, "radiobuttonH");
sexef=lookup_widget(objet, "radiobuttonF");

strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(e.telephone,gtk_entry_get_text(GTK_ENTRY(telephone)));
strcpy(e.fonction,gtk_entry_get_text(GTK_ENTRY(fonction)));

e.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(sexeh)))
	{strcpy(e.sexe,"Homme");}
else	{strcpy(e.sexe,"Femme");}

ajouter_employe(e);
yt=create_dialog1();
gtk_widget_show(yt);
}


void
on_buttonCHR_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *eCHR, *prenom, *nom, *cin, *telephone, *fonction, *jour, *mois, *annee, *sexe;
  employe e;
  char cine[9] ;
 

  
  eCHR=lookup_widget(objet, "eCHR");
  strcpy(cine,gtk_entry_get_text(GTK_ENTRY(eCHR)));
  
  e=rechercher(cine);

  FILE* f;
  f=fopen("employes.txt","r");
 
  prenom=lookup_widget (objet,"ePRM");
  nom=lookup_widget (objet,"eNOMM");
  cin=lookup_widget (objet,"eCINM");
  telephone=lookup_widget (objet,"eTELM");
  fonction=lookup_widget (objet,"eTAFM");;
  jour=lookup_widget (objet,"spinbuttonJM");
  mois=lookup_widget (objet,"spinbuttonMM");
  annee=lookup_widget (objet,"spinbuttonAM");
  sexe=lookup_widget (objet,"radiobuttonS");
  gtk_entry_set_text (GTK_ENTRY(prenom),e.prenom);
  gtk_entry_set_text (GTK_ENTRY(nom),e.nom);
  gtk_entry_set_text (GTK_ENTRY(cin),e.cin);
  gtk_entry_set_text (GTK_ENTRY(telephone),e.telephone);
  gtk_entry_set_text (GTK_ENTRY(fonction),e.fonction);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),e.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),e.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee),e.annee);
  gtk_entry_set_text (GTK_ENTRY(sexe),e.sexe);
  
  
  

  
  fclose(f);
}


void
on_BF_clicked                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gestionemploye=lookup_widget(objet_graphique,"gestionemploye");
notebook1=lookup_widget(gestionemploye,"notebook1");
treeAFF=lookup_widget(gestionemploye,"treeAFF");
afficher_employe(treeAFF);

}



void
on_radiobuttonH_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttonF_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_SUP_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *nom, *prenom, *cin, *telephone, *fonction, *jour, *mois, *annee, *sexe, *outpout;
  employe e;
char cine[9];
int suppri;
  FILE* f;

  prenom=lookup_widget (objet,"ePRM");
  nom=lookup_widget (objet,"eNOMM");
  cin=lookup_widget (objet,"eCINM");
  telephone=lookup_widget (objet,"eTELM");
  fonction=lookup_widget (objet,"eTAFM");;
  jour=lookup_widget (objet,"spinbuttonJM");
  mois=lookup_widget (objet,"spinbuttonMM");
  annee=lookup_widget (objet,"spinbuttonAM");
  sexe=lookup_widget (objet,"radiobuttonS");
   
   outpout=lookup_widget (objet,"ERR");
   strcpy (cine,gtk_entry_get_text(GTK_ENTRY(cin)));
   suppri=supprimer_employe(e,cine);
  if (suppri==1)
   {
  gtk_label_set_text (GTK_LABEL(outpout),"employe supprimé");
	printf("employe supprimé");
   }

}

void
on_buttonMOD_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *prenom, *nom, *cin, *telephone, *fonction, *jour, *mois, *annee, *sexe;
GtkWidget *yt;
  employe e1;

  char cine[9];
  
  
  FILE* f;
  f=fopen("employes.txt","r");

  prenom=lookup_widget (objet,"ePRM");
  nom=lookup_widget (objet,"eNOMM");
  cin=lookup_widget (objet,"eCINM");
  telephone=lookup_widget (objet,"eTELM");
  fonction=lookup_widget (objet,"eTAFM");;
  jour=lookup_widget (objet,"spinbuttonJM");
  mois=lookup_widget (objet,"spinbuttonMM");
  annee=lookup_widget (objet,"spinbuttonAM");
  sexe=lookup_widget (objet,"radiobuttonS");
  
strcpy(e1.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e1.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e1.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(e1.telephone,gtk_entry_get_text(GTK_ENTRY(telephone)));
strcpy(e1.fonction,gtk_entry_get_text(GTK_ENTRY(fonction)));



e1.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e1.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e1.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));



strcpy(e1.sexe,gtk_entry_get_text(GTK_ENTRY(sexe)));




  modifier_employe(e1);
  fclose(f);

yt=create_dialog1();
gtk_widget_show(yt);

}


void
on_AFAC_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
gestionemploye=lookup_widget(objet, "gestionemploye");
gtk_widget_destroy(gestionemploye);
gestionemploye=create_gestionemploye();
gtk_widget_show(gestionemploye);
}


void
on_button6_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

}



void
on_CHAB_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *eABCH, *taux;
  absence a;
  char cine[9] ;
 

  
  eABCH=lookup_widget(objet, "eABCH");
  strcpy(cine,gtk_entry_get_text(GTK_ENTRY(eABCH)));
  
  a=recherch(cine);
  taux=lookup_widget (objet,"spinbuttonT");
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(taux),a.taux);

}


void
on_MQAB_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *cin, *taux, *nbabs, *nbpr;
  
  absence a1;
  absence a2;

  char cine[9];
  
  
  FILE* f;
  f=fopen("absence.txt","r");

  cin=lookup_widget (objet,"eABCH");
  nbabs=lookup_widget (objet,"radiobuttonAB");

strcpy(a1.cin,gtk_entry_get_text(GTK_ENTRY(cin)));

a2=recherch(a1.cin);
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(nbabs)))
	{a2.nbabs++;
	 a2.taux=(100/(a2.nbabs+a2.nbpr))*a2.nbabs;
	}
	
else	{a2.nbpr++;
	 a2.taux=(100/(a2.nbabs+a2.nbpr))*a2.nbabs;
	}

  modifier_abs(a2);
  fclose(f);
}


void
on_button1000_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *eNAB;
GtkWidget *yy;
  absence a;
  a=meilleur ();
  eNAB=lookup_widget (objet,"eNAB");
  gtk_entry_set_text (GTK_ENTRY(eNAB),a.cin);

yy=create_dialog2();
gtk_widget_show(yy);

}
////////////////////////////fin khalil /////////////////////////////



//////////////////////////////ALA ///////////////////////////////////////

int ala;
int achoix;
void
Refresh1                               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"ListCapteures");
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview5") ;
	AfficherListCapteures(treeview);
}


void
AddCap                                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	Capteur p;
	GtkWidget *reference,*type,*marque,*bi,*bs,*jour, *mois, *annee, *ajouter,*pInfo ;
	char ver[30];

	reference=lookup_widget(objet_graphique,"RefEntry");
	type=lookup_widget(objet_graphique,"ComboType");
	marque=lookup_widget(objet_graphique,"MarqueEntry");

	bi=lookup_widget(objet_graphique, "spinbuttonBI");
	bs=lookup_widget(objet_graphique, "spinbuttonBS");
	jour=lookup_widget(objet_graphique, "spinbuttonJ");
	mois=lookup_widget(objet_graphique, "spinbuttonM");
	annee=lookup_widget(objet_graphique, "spinbuttonA");

if( (is_empty(reference)==0) /*|| (is_empty(type)==0) */|| (is_empty(marque)==0) || (is_empty(bi)==0) 
 || (is_empty(bs)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"label208");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_entry_get_text(GTK_ENTRY(reference)));
	if(existe(ver)==1)
{
	GtkWidget *existe=lookup_widget(objet_graphique,"Existe");
        gtk_label_set_text(GTK_LABEL(existe),"reference existe deja !");
}
else {

	
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	strcpy(p.typeDeCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
	strcpy(p.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
	
	p.dateMiseEnOeuvre.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateMiseEnOeuvre.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateMiseEnOeuvre.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	if( achoix == 0 )
	{

	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_ERROR,
	GTK_BUTTONS_OK,
	"Vous devez choisir \n l'etat du capteur SVP");
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{
	gtk_widget_destroy(pInfo);
	
	}

	}
else {
	if( achoix == 1 )
	{
	p.etat = 1;
	}
	if( achoix == 2 )
	{
	p.etat = 2;
	}
	if( achoix == 3 )
	{
	p.etat = 3;
	}


	p.BI=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bi));
	p.BS=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bs));

	if((p.dateMiseEnOeuvre.jour >= 32) || (p.dateMiseEnOeuvre.mois >= 13) ||  (p.dateMiseEnOeuvre.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"FormatDate");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	AjouterCapteur(p);
	
	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_INFO,
	GTK_BUTTONS_OK,
	"Ajout avec succée de : %s",p.typeDeCapteur);
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{
	ajouter=lookup_widget(objet_graphique,"InterfaceAddCapteurAdmin");
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview5") ;
	AfficherListCapteures(treeview);
	}
	

}
}
}
}
}


void
RemoveCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cet Capteur ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

	
        
        p=lookup_widget(objet_graphique,"treeview5");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           
		
        	supprimerCapteur(id); // supprimer de l'interface capteur
		SupprimerValeur2(id); // supprimer de l'interface historiqueCapteur
		printf("id supprimer est : %s \n",id);
		
		char tt[80];
		strcpy(tt,"Un capteur qui a la référence -");
		strcat(tt,id);
		strcat(tt,"- a été supprimer avec succés :) ");
	
	/*twilio_send_message("AC36519c8d5b3d7c49ae1397cb6196de86",
			    "27508283f178a45b113555b7ebd5b0a2",
			    tt,
			    "+12056795511",
			    "21651078016",
			    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSF9GM5mq97W_EPvDu7JH_n_VR9ZsOTEWQq4Q&usqp=CAU",
			     true);*/
	
	ajouter=lookup_widget(objet_graphique,"ListCapteures");
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview5") ;
	AfficherListCapteures(treeview);
	
        }
           
	
	
	gtk_widget_destroy(pQuestion);
           


	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}


}


void
RedirectAddCap                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"ListCapteures");
	ajouter = create_InterfaceAddCapteurAdmin();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);

}


void
RedirectUpdateCap                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *w2,*w1;
	w1 = lookup_widget(objet_graphique, "ListCapteures") ;
	w2 = lookup_widget(objet_graphique, "ModificationCapteur") ;
	w2 = create_ModificationCapteur();
	gtk_widget_show (w2);
	gtk_widget_hide (w1);

}





void
SearchCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry23") ;
	w1=lookup_widget(objet_graphique,"ListCapteures");
	if((is_empty(search)==0)  )
	{
		GtkWidget *control=lookup_widget(objet_graphique,"label214");
                gtk_label_set_text(GTK_LABEL(control),"Champ manquant!!");

	}
	else {
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_ListCapteures();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview5") ;
	ChercherCapteur(treeview,ss);
	}
}


void
acceuil                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceAddCapteurAdmin");
	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview5") ;
	AfficherListCapteures(treeview);

}


void
ModifierFN                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

Capteur p;
	GtkWidget *reference,*ref1,*type,*marque,*bi,*bs,*jour, *mois, *annee, *ajouter, *update,*pInfo ;
	char ver[30];

	
	ref1=lookup_widget(objet_graphique,"combobox9");
	type=lookup_widget(objet_graphique,"combo1Type");
	marque=lookup_widget(objet_graphique,"Marque1Entry");

	bi=lookup_widget(objet_graphique, "spinbutton1BI");
	bs=lookup_widget(objet_graphique, "spinbutton1BS");
	jour=lookup_widget(objet_graphique, "spinbutton1J");
	mois=lookup_widget(objet_graphique, "spinbutton1M");
	annee=lookup_widget(objet_graphique, "spinbutton1A");

if(  (is_empty(marque)==0) || (is_empty(bi)==0) 
 || (is_empty(bs)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"Remplir");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));
	

	
	strcpy(p.ref,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));
	strcpy(p.typeDeCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
	strcpy(p.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
	if( ala == 0 )
	{

	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_INFO,
	GTK_BUTTONS_OK,
	"Vous devez choisir \n l'etat du Capteur ?");
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{
	gtk_widget_destroy(pInfo);
	
	}

	}
	if( ala == 1 )
	{
	p.etat = 1;
	}
	if( ala == 2 )
	{
	p.etat = 2;
	}
	if( ala == 3 )
	{
	p.etat = 3;
	}
	
	p.dateMiseEnOeuvre.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateMiseEnOeuvre.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateMiseEnOeuvre.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));


	p.BI=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bi));
	p.BS=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(bs));

	if((p.dateMiseEnOeuvre.jour >= 32) || (p.dateMiseEnOeuvre.mois >= 13) ||  (p.dateMiseEnOeuvre.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"DateF");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierCapteur(p,ver);
	
	pInfo = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_INFO,
	GTK_BUTTONS_OK,
	"Modification avec succée \n de capteur ayant la référence : %s",p.ref);
	gtk_dialog_run(GTK_DIALOG(pInfo));
	gtk_widget_destroy(pInfo);
	if(GTK_RESPONSE_OK)
	{

	update=lookup_widget(objet_graphique,"ModificationCapteur");
	
	

	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (update);
	treeview = lookup_widget(ajouter, "treeview5") ;
	AfficherListCapteures(treeview);
	}

	
	
	


}
}

}


void
AllerHistoqrique                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	afficher=lookup_widget(objet_graphique,"ListCapteures");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview6") ;
	AfficherHistorique(treeview);

}


void
RetourAcceuil                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceAjout_h");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
        treeview = lookup_widget(ajouter, "treeview6") ;
	AfficherHistorique(treeview);

}


void
AjouterHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	historiqueCapteur p;
	GtkWidget *reference,*refCap,*valeur,*jour, *mois, *annee, *ajouter ;
	char ver[30];

	refCap=lookup_widget(objet_graphique,"combobox10");
	
	reference=lookup_widget(objet_graphique,"entry24");
	valeur=lookup_widget(objet_graphique,"spinbutton28");
	jour=lookup_widget(objet_graphique, "spinbutton29");
	mois=lookup_widget(objet_graphique, "spinbutton30");
	annee=lookup_widget(objet_graphique, "spinbutton31");

if( (is_empty(valeur)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"label232");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	

	
	strcpy(p.refCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(refCap)));
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	
	
	
	p.datePreleveemnt.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.datePreleveemnt.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.datePreleveemnt.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));
	

	if((p.datePreleveemnt.jour >= 32) || (p.datePreleveemnt.mois >= 13) ||  (p.datePreleveemnt.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label237");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	AjouterValeur(p);

	afficher=lookup_widget(objet_graphique,"InterfaceAjout_h");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	
	treeview = lookup_widget(ajouter, "treeview6") ;
	AfficherHistorique(treeview);


}
}



}


void
RedirectAddHis                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	afficher=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	ajouter = create_InterfaceAjout_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);

}


void
SuppHis                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cette valeur ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

	
        
        p=lookup_widget(objet_graphique,"treeview6");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           
			//printf("id est : %s \n",id);
           SupprimerValeur(id);
	ajouter=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview6") ;
	AfficherHistorique(treeview);
	
        }
           
	
	
	gtk_widget_destroy(pQuestion);
           


	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}

}


void
allerModifHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *w2,*w1;
	w1 = lookup_widget(objet_graphique, "InterfaceAfficher_h") ;
	w2 = lookup_widget(objet_graphique, "InterfaceUpdate_h") ;
	w2 = create_InterfaceUpdate_h();
	gtk_widget_show (w2);
	gtk_widget_hide (w1);

}


void
RefreshHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview6") ;
	AfficherHistorique(treeview);
	

}


void
RetourCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview5") ;
	AfficherListCapteures(treeview);

}


void
SearchHis                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry25") ;
	w1=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	if((is_empty(search)==0)  )
	{
		GtkWidget *control=lookup_widget(objet_graphique,"label255");
                gtk_label_set_text(GTK_LABEL(control),"Champ manquant!!");

	}
	else {
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview6") ;
	ChercherValeur(treeview,ss);
	}

}


void
modifierHis                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	historiqueCapteur p;
	GtkWidget *reference,*refCap,*valeur,*jour, *mois, *annee, *ajouter ;
	char ver[30];


	refCap=lookup_widget(objet_graphique,"combobox11");
	reference=lookup_widget(objet_graphique,"combobox12");
	valeur=lookup_widget(objet_graphique,"spinbutton32");
	jour=lookup_widget(objet_graphique, "spinbutton33");
	mois=lookup_widget(objet_graphique, "spinbutton34");
	annee=lookup_widget(objet_graphique, "spinbutton35");

if(    (is_empty(valeur)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"label251");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	

	
	strcpy(p.refCapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(refCap)));
	strcpy(p.ref,gtk_combo_box_get_active_text(GTK_COMBO_BOX(reference)));
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(reference)));
	

	
	p.datePreleveemnt.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.datePreleveemnt.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.datePreleveemnt.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));
	

	if((p.datePreleveemnt.jour >= 32) || (p.datePreleveemnt.mois >= 13) ||  (p.datePreleveemnt.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label250");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierValeur(p,ver);

	ajouter=lookup_widget(objet_graphique,"InterfaceUpdate_h");
	
	
	gtk_widget_hide (ajouter);
	afficher = create_InterfaceAfficher_h();
	gtk_widget_show (afficher);
	
	treeview = lookup_widget(afficher, "treeview6") ;
	AfficherHistorique(treeview);


}
}


}


void
ValiderRef                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox10");
	btn=lookup_widget(objet_graphique,"Valider");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference.txt");

}


void
ValiderModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox12");
	btn=lookup_widget(objet_graphique,"button1016");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef1();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference1.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference1.txt");

}


void
RemplirModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *ref,*refCapteur,*val,*annee,*jour,*mois;

	refCapteur=lookup_widget(objet_graphique,"combobox11");
	ref=lookup_widget(objet_graphique,"combobox12");
	val=lookup_widget(objet_graphique,"spinbutton32");
	
	jour=lookup_widget(objet_graphique,"spinbutton33");
	mois=lookup_widget(objet_graphique,"spinbutton34");
	annee=lookup_widget(objet_graphique,"spinbutton35");

	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref)));	
	historiqueCapteur c;
	FILE *f=NULL;
	f = fopen("historiqueCapteur.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %d %d %d %d \n" ,c.ref,c.refCapteur,&c.valeur,&c.datePreleveemnt.annee,&c.datePreleveemnt.mois,&c.datePreleveemnt.jour)!=EOF)

	{
	if(strcmp(var,c.ref)==0)
	{
	
	gtk_spin_button_set_value (val, c.valeur);
	gtk_combo_box_append_text (GTK_COMBO_BOX(refCapteur),(c.refCapteur));
	gtk_spin_button_set_value (annee, c.datePreleveemnt.annee);
	gtk_spin_button_set_value (mois, c.datePreleveemnt.mois);
	gtk_spin_button_set_value (jour, c.datePreleveemnt.jour);

	}

	
	}
	}
	fclose(f);

}


void
ValiderCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox9");
	btn=lookup_widget(objet_graphique,"button1011");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference.txt");

}


void
RemplirCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *ref1,*type,*marque,*bi,*on,*off,*panne,*bs,*etat,*annee,*jour,*mois;

	ref1=lookup_widget(objet_graphique,"combobox9");
	type=lookup_widget(objet_graphique,"combo1TYpe");
	marque=lookup_widget(objet_graphique,"Marque1Entry");
	
	bi=lookup_widget(objet_graphique,"spinbutton1BI");
	bs=lookup_widget(objet_graphique,"spinbutton1BS");


	jour=lookup_widget(objet_graphique,"spinbutton1J");
	mois=lookup_widget(objet_graphique,"spinbutton1M");
	annee=lookup_widget(objet_graphique,"spinbutton1A");
	on=lookup_widget(objet_graphique,"checkbutton8");
	off=lookup_widget(objet_graphique,"checkbutton9");
	panne=lookup_widget(objet_graphique,"checkbutton10");

	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));	
	Capteur c;
	FILE *f=NULL;
	f = fopen("capteurs.txt","r");
	if(f!=NULL)
	{while (fscanf(f,"%s %s %s %d %d %d %d %d %d \n" ,c.ref,c.typeDeCapteur,c.marque,&c.BI,&c.BS,&c.etat
,&c.dateMiseEnOeuvre.annee,&c.dateMiseEnOeuvre.mois,&c.dateMiseEnOeuvre.jour)!=EOF)

	{
	if(strcmp(var,c.ref)==0)
	{
	gtk_entry_set_text (marque,c.marque);
	gtk_combo_box_append_text (GTK_COMBO_BOX(type),(c.typeDeCapteur));
	gtk_spin_button_set_value (bi, c.BI);
	gtk_spin_button_set_value (bs, c.BS);
if(c.etat == 0)
{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(off), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(on), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(panne), FALSE);
}
if(c.etat== 1)
{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(on), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(off), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(panne), FALSE);
}
if(c.etat== 2)
{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(panne), TRUE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(on), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(off), FALSE);
}

	gtk_spin_button_set_value (jour, c.dateMiseEnOeuvre.jour);
	gtk_spin_button_set_value (mois, c.dateMiseEnOeuvre.mois);
	gtk_spin_button_set_value (annee, c.dateMiseEnOeuvre.annee);

	}

	
	}
	}
	fclose(f);

}


void
BackfromUpdate                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	afficher=lookup_widget(objet_graphique,"ModificationCapteur");
	ajouter = create_ListCapteures();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview5") ;
	AfficherListCapteures(treeview);

}


void
BackfromUpHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	afficher=lookup_widget(objet_graphique,"InterfaceUpdate_h");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview6") ;
	AfficherHistorique(treeview);

}


void
CapOn                                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
achoix=1;

}


void
CapOff                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
achoix=3;

}


void
CapPanne                               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
achoix=2;

}


void
CapUpdateOn                            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
ala=1;

}


void
CapUpdateOff                           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
ala=3;

}


void
CapUpdatePannne                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
ala=2;

}


void
GoToAlaramant                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
	lirefscanf();
	afficher=lookup_widget(objet_graphique,"InterfaceAfficher_h");
	ajouter = create_CapAlarmante();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview7") ;
	AfficherAlarmante(treeview);
	

	
	
	

}


void
BackFromAlarmante                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{	
	remove("fichierTestAlaramante.txt");
	GtkWidget *treeview;
	afficher=lookup_widget(objet_graphique,"CapAlarmante");
	ajouter = create_InterfaceAfficher_h();
	gtk_widget_show (ajouter);
	gtk_widget_hide (afficher);
	treeview = lookup_widget(ajouter, "treeview6") ;
	AfficherHistorique(treeview);

}



/////////////////////////////////wassim //////////////////////////////////////////////

GtkWidget *afficher,*treeview ,*ajouter,*update;



int iss_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}


int existee(char ver[30]) {
FILE *f;
f = fopen("troupeau.txt","r");
int find=0;
char ref[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,ref)!=EOF)
{
if(strcmp(ver,ref)==0)
find=1;
}
}
else
printf("erreur \n");
return find;
}


void
AddTroup                               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	Troupeau p;
	GtkWidget *reference,*race,*couleur,*poid,*jour, *mois, *annee, *ajouter ;
	char ver[30];

	reference=lookup_widget(objet_graphique,"entry27");
	race=lookup_widget(objet_graphique,"entry28");
	couleur=lookup_widget(objet_graphique,"entry29");
	poid=lookup_widget(objet_graphique, "spinbutton36");
	jour=lookup_widget(objet_graphique, "spinbutton37");
	mois=lookup_widget(objet_graphique, "spinbutton38");
	annee=lookup_widget(objet_graphique, "spinbutton39");

if( (iss_empty(reference)==0) || (iss_empty(race)==0) ||  (iss_empty(couleur)==0) || (iss_empty(poid)==0))
{
		GtkWidget *control=lookup_widget(objet_graphique,"label17");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_entry_get_text(GTK_ENTRY(reference)));
	if(existee(ver)==1)
{
	GtkWidget *existe=lookup_widget(objet_graphique,"label19");
        gtk_label_set_text(GTK_LABEL(existe),"reference existe deja !");
}
else {

	
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	strcpy(p.race,gtk_entry_get_text(GTK_ENTRY(race)));
	strcpy(p.couleur,gtk_entry_get_text(GTK_ENTRY(couleur)));
	
	p.dateDeNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateDeNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateDeNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.poid_a_la_naissance=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(poid));


	if((p.dateDeNaissance.jour >= 32) || (p.dateDeNaissance.mois >= 13) ||  (p.dateDeNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label18");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	AjouterTroupeau(p);

	ajouter=lookup_widget(objet_graphique,"InterfaceAjoutTroupeau");
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview8") ;
	AfficherListTroupeau(treeview);

}
}
}


}


void
RedirectAddTroup                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceAjoutTroupeau();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);

}


void
RemoveTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cete Troupeau ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

	
        
        p=lookup_widget(objet_graphique,"treeview8");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           

           supprimerTroupeau(id);
	ajouter=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview8") ;
	AfficherListTroupeau(treeview);
	
        }
           
	
	
	gtk_widget_destroy(pQuestion);
           


	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}

}


void
RedirectUpdateTroup                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceUpdateTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);

}


void
RefreshTroup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview8") ;
	AfficherListTroupeau(treeview);
	

}


void
SearchTraoup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	
	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry26") ;
	w1=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	if((iss_empty(search)==0)  )
	{
		GtkWidget *control=lookup_widget(objet_graphique,"label6");
                gtk_label_set_text(GTK_LABEL(control),"Champ manquant!!");

	}
	else {
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview8") ;
	ChercherTroupeau(treeview,ss);
	}

}


void
UpdateTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{



	Troupeau p;
	GtkWidget *reference,*ref1,*race,*couleur,*poid,*jour, *mois, *annee, *ajouter, *update ;
	char ver[30];

	reference=lookup_widget(objet_graphique,"entry30");
	ref1=lookup_widget(objet_graphique,"combobox13");
	race=lookup_widget(objet_graphique,"entry31");
	couleur=lookup_widget(objet_graphique,"entry32");
	poid=lookup_widget(objet_graphique, "spinbutton40");
	jour=lookup_widget(objet_graphique, "spinbutton41");
	mois=lookup_widget(objet_graphique, "spinbutton42");
	annee=lookup_widget(objet_graphique, "spinbutton43");

if( (iss_empty(reference)==0) || (iss_empty(race)==0) || (iss_empty(couleur)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"label33");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));
	

	
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	strcpy(p.race,gtk_entry_get_text(GTK_ENTRY(race)));
	strcpy(p.couleur,gtk_entry_get_text(GTK_ENTRY(couleur)));
	
	p.dateDeNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateDeNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateDeNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.poid_a_la_naissance=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(poid));


	if((p.dateDeNaissance.jour >= 32) || (p.dateDeNaissance.mois >= 13) ||  (p.dateDeNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label31");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierTroupeau(p,ver);

	update=lookup_widget(objet_graphique,"InterfaceUpdateTroup");
	gtk_widget_hide (update);
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview8") ;
	AfficherListTroupeau(treeview);

	
	
	


}
}

}


void
ValiderReference                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox13");
	btn=lookup_widget(objet_graphique,"button1035");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference.txt");

	

}


void
RemplirChampss                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *ref,*race,*couleur,*poid,*annee,*jour,*mois,*btn,*ref1;
	btn=lookup_widget(objet_graphique,"button1036");
	//gtk_widget_set_sensitive ( btn, FALSE);
	ref=lookup_widget(objet_graphique,"entry30");
	ref1=lookup_widget(objet_graphique,"combobox13");
	race=lookup_widget(objet_graphique,"entry31");
	couleur=lookup_widget(objet_graphique,"entry32");
	poid=lookup_widget(objet_graphique,"spinbutton40");
	jour=lookup_widget(objet_graphique,"spinbutton41");
	mois=lookup_widget(objet_graphique,"spinbutton42");
	annee=lookup_widget(objet_graphique,"spinbutton43");
	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));	
	Troupeau t;
	FILE *f=NULL;
	f = fopen("troupeau.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %s %d %d %d %d \n " ,t.ref,t.race,t.couleur,&t.poid_a_la_naissance,&t.dateDeNaissance.annee
,&t.dateDeNaissance.mois,&t.dateDeNaissance.jour)!=EOF)

	{
	if(strcmp(var,t.ref)==0)
	{
	gtk_entry_set_text (ref,t.ref);
	gtk_entry_set_text (race,t.race);
	gtk_entry_set_text (couleur,t.couleur);
	gtk_spin_button_set_value (poid, t.poid_a_la_naissance);
	gtk_spin_button_set_value (annee, t.dateDeNaissance.annee);
	gtk_spin_button_set_value (mois, t.dateDeNaissance.mois);
	gtk_spin_button_set_value (jour, t.dateDeNaissance.jour);

	}

	
	}
	}
	fclose(f);
	

}


void
BackUpdate                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	update=lookup_widget(objet_graphique,"InterfaceUpdateTroup");
	gtk_widget_hide (update);
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview8") ;
	AfficherListTroupeau(treeview);

}


void
BackAdd                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	update=lookup_widget(objet_graphique,"InterfaceAjoutTroupeau");
	gtk_widget_hide (update);
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview8") ;
	AfficherListTroupeau(treeview);

}


void
on_button1031__clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
{
GtkWidget *windowstat, *windowtroup;
windowtroup=lookup_widget(objet,"InterfaceAfficherTroup");
gtk_widget_destroy(windowtroup);
windowstat=create_interfacestatistique();
gtk_widget_show (windowstat);
}

}


void
on_button1039_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *out1, *out2, *out3, *out4 ;

char V[30];
int nb1=0;

char P[30];
int nb2=0;

char M[30];
int nb3=0;

char C[30];
int nb4=0;
out1 = lookup_widget(objet,"label308");
out2 = lookup_widget(objet,"label309");
out3 = lookup_widget(objet,"label306");
out4 = lookup_widget(objet,"label305");
nbtoupeaux(&nb1,&nb2,&nb3,&nb4);
sprintf(V,"%d",nb1);
gtk_label_set_text(GTK_LABEL(out1),V);
sprintf(P,"%d",nb2);
gtk_label_set_text(GTK_LABEL(out2),P);
sprintf(M,"%d",nb3);
gtk_label_set_text(GTK_LABEL(out3),M);
sprintf(C,"%d",nb4);
gtk_label_set_text(GTK_LABEL(out4),C);

}


void
on_button1040_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowstat, *windowtroup;
windowstat=lookup_widget(objet,"interfacestatistique");
gtk_widget_destroy(windowstat);
windowtroup=create_InterfaceAfficherTroup();
gtk_widget_show (windowtroup);



}
////////////////////////////fin///////////////////////
