#include <gtk/gtk.h>

///////////////////Interg/////////////////////////////////
void
on_connexion_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Inscrire_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_alleremploye_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_allercapteur_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_allerouvrier_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_allerequipement_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_allertroupeaux_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quit_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_inscription_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);
/////////////////////////////////////////////////////////////

//////////////////////// WAEL/////////////////////////////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ok_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_non_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_back_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_charge_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_radiobuttonmod2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonmod1_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_consulter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_display_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modify_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_delete_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_recuperer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_back1_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Annuler1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_annule_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_load_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valide_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
///////////////////////////////////////////////////////////////////////////////

////////////////////////:dhia //////////////////////////////
void
RedirectToAdd                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AddOuvrier                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SuppOuvrier                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectToUpdate                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
Refresh                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
REdirectToAfficher                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderCombo                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirChamps                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
UpdateOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
ModifOuvrier                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ChercherOuvrier                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
BackFromUpdateOuv                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
GoToAbs                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
AddAbsence                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AbsOui                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
AbsNon                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
ValiderRefAbs                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
RemoveAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SearchAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RefreshAbs                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ResirectAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackFromAddAbs                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackFromUpdateAbs                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RetourOuvrier                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirUpdateAbs                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
OuiUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
NonUpdate                              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
UpdateAbs                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
CalculerTaux                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
ValiderRefAbs                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
AbsOui                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
AbsNon                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
AddAbsence                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
////////////////////////////////Fin dhia ////////////////////////////

/////////////////////////khalil ////////////////////////////////////

void
on_button1000_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_buttonAJ_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonCHR_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_BF_clicked                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonH_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonF_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_SUP_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonMOD_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_AFAC_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CHAB_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MQAB_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

gboolean
on_spinbuttonT_output                  (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

////////////////////////fin khalil ////////////////////////////////

////////////////////////ALA ///////////////////////////////////

void
AddCap                                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemoveCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectAddCap                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectUpdateCap                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
Refresh1                               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
SearchCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
acceuil                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ModifierFN                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AllerHistoqrique                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RetourAcceuil                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
AjouterHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectAddHis                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SuppHis                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
allerModifHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RefreshHis                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RetourCap                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SearchHis                              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
modifierHis                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderRef                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirModif                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirCap                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackfromUpdate                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackfromUpHis                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
CapOn                                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapOff                                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapPanne                               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapUpdateOn                            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapUpdateOff                           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
CapUpdatePannne                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
GoToAlaramant                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackFromAlarmante                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



//////////////////////////////////WAssim///////////////////////


void
AddTroup                               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectAddTroup                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemoveTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectUpdateTroup                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RefreshTroup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SearchTraoup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
UpdateTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderReference                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirChampss                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackUpdate                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackAdd                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1031__clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1039_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1040_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
