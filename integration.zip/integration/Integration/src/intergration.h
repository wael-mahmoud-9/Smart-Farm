
#include <gtk/gtk.h>


////////////////////////////WAEL	////////////////////////////////////

typedef struct {
char id[50];
char marque[50];
char type[50];
char etat[50];
char prix[50];
char dispo[50];
}equipement;


///////////////Fonctions CRUD///////////////////////////////

void ajouter_eq(equipement x);

void modifier_eq(equipement x, char *id);

void supprimer_eq(char *id);

void rechercher_eq(GtkWidget *liste,char id1[30]);


////////////////////TREEVIEW///////////////////////////////

void afficher_eq(GtkWidget *liste);


////////////////////Verification//////////////////////////

int vide(GtkWidget *entry);

int exist(char ver[30]);


typedef struct {
int annee;
int pmin;
int pmax;
int ptot;
}donnee;



///////////////Fonctions CRUD///////////////////////////////


void ajouter_don(donnee x);

void modifier_don(char sh[20],char sh2[20],char sh3[20],char sh4[20], char *g);

void supprimer_don(char *g);

int calcule(int x,int y);

////////////////////TREEVIEW///////////////////////////////

void afficher_don(GtkWidget *liste);
//////////////////////////FIN WAEL	//////////////////////////////////

/////////////////////INTEgration///////////////////////////////////
typedef struct {
char username[30];
char password[30];
}admin;

//////Ajouter///////////
void ajouter_ad(admin a);
//////Verif/////////////
int verifier(char e1[30],char e2[30]);
//////////////////////////////FIN INTE ///////////////////////////////

/////////////////////////////DHIA/////////////////////////:
typedef struct Date
{

	int jour;
	int mois;
	int annee;
	
}Date; 

typedef struct {
char id[30];
char nom[30];
char prenom[30] ;
char tel[30];
char fonction[30];
Date dateEmbauche ;
Date dateNaissance ;

}Ouvrier;


void AjouterOuvrier(Ouvrier c ) ;
void AfficherListOuvrier(GtkWidget *liste) ;
void ModifierOuvrier(Ouvrier c , char id[30]);
void supprimerOuvrier(char id[30]) ;
void ChercherOuv (GtkWidget *liste, char id1[30]) ;



typedef struct Datee
{

	int jour;
	int mois;
	int annee;
	
}Datee; 

typedef struct {
char id[30];
char idOuvrier[30];
Datee date;
char abs[10] ;

}Absence;


void AjouterAbsence(Absence c ) ;
void AfficherListAbsence(GtkWidget *liste) ;
void ModifierAbsence(Absence c , char id[30]);
void supprimerAbsence(char id[30]) ;
void ChercherAbsence (GtkWidget *liste, char id1[30]) ;


//////////////////////FIN DHIA //////////////////////////////

/////////////////////////Khalil /////////////////////////////////

struct employe
{

	char nom[30];
	char prenom[30];
	char cin[30];
	char telephone[30];
	char fonction[30];
	int jour;
	int mois;
	int annee;
	char sexe[30];



}; typedef struct employe employe;
struct absence
{

	char nom[30];
	char prenom[30];
	char cin[30];
	int taux;
	int nbabs;
	int nbpr;



}; typedef struct absence absence;

void ajouter_employe(employe e);
int controle(char cin[]);
void afficher_employe(GtkWidget *liste);
void modifier_employe(employe e1);
employe rechercher (char cin[30]);
int supprimer_employe(employe e,char cin[30]);
absence recherch (char cin[30]);
void modifier_abs(absence a1);
absence meilleur ();
/////////////////////////FIn khalil ./////////////////////////////



//////////////////////////ALA///////////////////////////////////



typedef struct aDate
{

	int jour;
	int mois;
	int annee;
	
}aDate; 

typedef struct {
char ref[30];
char marque[30];
char typeDeCapteur[30] ;
int BI;
int BS;
int  etat;  //(1: On , 0:OFF , 2:EnPanne)
aDate dateMiseEnOeuvre ;

}Capteur;


void AjouterCapteur(Capteur c ) ;
void AfficherListCapteures(GtkWidget *liste) ;
void ModifierCapteur(Capteur c , char ref[30]) ;
void supprimerCapteur(char ref[30]) ;
void ChercherCapteur (GtkWidget *liste, char refe[30]) ;
int is_empty(GtkWidget *entry) ;
int existe(char ver[30]) ;



typedef struct aDatee
{

	int jour;
	int mois;
	int annee;
	
}aDatee;

typedef struct  {
char ref[30];
char refCapteur[30];
int valeur;
aDatee datePreleveemnt ;
} historiqueCapteur;

void AjouterValeur(historiqueCapteur hc) ;
void AfficherHistorique(GtkWidget *liste) ;
void ModifierValeur( historiqueCapteur hc , char ref[30]) ;
void SupprimerValeur(char ref[30]) ;
void ChercherValeur (GtkWidget *liste, char refe[30]) ;
void CapAlarmantes() ;
void Verification(/*int valeur,char refCap[30]*/);



///////////////////////////////////////FIN ALA/////////////////////////////////////////


///////////////////////WASSIM ////////////////////////////////////////////

typedef struct wDatee
{

	int jour;
	int mois;
	int annee;
	
}wDatee; 

typedef struct {
char ref[30];
char race[30];
char couleur[30] ;
int poid_a_la_naissance;
wDatee dateDeNaissance ;

}Troupeau;


void AjouterTroupeau(Troupeau t ) ;

void AfficherListTroupeau(GtkWidget *liste) ;
void ModifierTroupeau(Troupeau c , char ref[30]) ;
void supprimerTroupeau(char ref[30]) ;
void ChercherTroupeau (GtkWidget *liste, char refe[30]) ;
int is_empty(GtkWidget *entry) ;
int existe(char ver[30]) ;
void nbtoupeaux ();


//////////////////////////////FIN WASSIM ///////////////////
