#include <gtk/gtk.h>


void
AddTroup                               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectAddTroup                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemoveTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RedirectUpdateTroup                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RefreshTroup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
SearchTraoup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
UpdateTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
ValiderReference                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
RemplirChamps                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackUpdate                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
BackAdd                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12__clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
