#ifndef FONCTION_H_
#define FONCTIONS_H_
#include <stdbool.h>


typedef struct Date
{

	int jour;
	int mois;
	int annee;
	
}Date; 

typedef struct {
char ref[30];
char race[30];
char couleur[30] ;
int poid_a_la_naissance;
Date dateDeNaissance ;

}Troupeau;


void AjouterTroupeau(Troupeau t ) ;

void AfficherListTroupeau(GtkWidget *liste) ;
void ModifierTroupeau(Troupeau c , char ref[30]) ;
void supprimerTroupeau(char ref[30]) ;
void ChercherTroupeau (GtkWidget *liste, char refe[30]) ;
int is_empty(GtkWidget *entry) ;
int existe(char ver[30]) ;






#endif
