#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "troupeau.c"


GtkWidget *afficher,*treeview ,*ajouter,*update;



int is_empty(GtkWidget *entry){
char ch[30];
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(ch,"")==0)return 0;
else return 1;
}


int existe(char ver[30]) {
FILE *f;
f = fopen("troupeau.txt","r");
int find=0;
char ref[30];
if(f!=NULL)
{
while (fscanf(f,"%s" ,ref)!=EOF)
{
if(strcmp(ver,ref)==0)
find=1;
}
}
else
printf("erreur \n");
return find;
}


void
AddTroup                               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	Troupeau p;
	GtkWidget *reference,*race,*couleur,*poid,*jour, *mois, *annee, *ajouter ;
	char ver[30];

	reference=lookup_widget(objet_graphique,"entry2");
	race=lookup_widget(objet_graphique,"entry3");
	couleur=lookup_widget(objet_graphique,"entry4");
	poid=lookup_widget(objet_graphique, "spinbutton1");
	jour=lookup_widget(objet_graphique, "spinbutton2");
	mois=lookup_widget(objet_graphique, "spinbutton3");
	annee=lookup_widget(objet_graphique, "spinbutton4");

if( (is_empty(reference)==0) || (is_empty(race)==0) ||  (is_empty(couleur)==0) || (is_empty(poid)==0))
{
		GtkWidget *control=lookup_widget(objet_graphique,"label17");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_entry_get_text(GTK_ENTRY(reference)));
	if(existe(ver)==1)
{
	GtkWidget *existe=lookup_widget(objet_graphique,"label19");
        gtk_label_set_text(GTK_LABEL(existe),"reference existe deja !");
}
else {

	
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	strcpy(p.race,gtk_entry_get_text(GTK_ENTRY(race)));
	strcpy(p.couleur,gtk_entry_get_text(GTK_ENTRY(couleur)));
	
	p.dateDeNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateDeNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateDeNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.poid_a_la_naissance=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(poid));


	if((p.dateDeNaissance.jour >= 32) || (p.dateDeNaissance.mois >= 13) ||  (p.dateDeNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label18");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	AjouterTroupeau(p);

	ajouter=lookup_widget(objet_graphique,"InterfaceAjoutTroupeau");
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListTroupeau(treeview);

}
}
}


}


void
RedirectAddTroup                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceAjoutTroupeau();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);

}


void
RemoveTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p ,*w1,*pQuestion;
        
        gchar* id;

	pQuestion = gtk_message_dialog_new(GTK_WINDOW(afficher),
	GTK_DIALOG_MODAL,
	GTK_MESSAGE_QUESTION,
	GTK_BUTTONS_YES_NO,
	"Voulez vous vraiments \n Supprimer cete Troupeau ?");

	switch (gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_YES:

	
        
        p=lookup_widget(objet_graphique,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           

           supprimerTroupeau(id);
	ajouter=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);
	
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListTroupeau(treeview);
	
        }
           
	
	
	gtk_widget_destroy(pQuestion);
           


	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pQuestion);
	break;

	}

}


void
RedirectUpdateTroup                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	ajouter=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceUpdateTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (ajouter);

}


void
RefreshTroup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *afficher,*w1;
	
	
	w1=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListTroupeau(treeview);
	

}


void
SearchTraoup                           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	
	GtkWidget *afficher,*w1,*search;
	char ss[30];
	search = lookup_widget(objet_graphique, "entry1") ;
	w1=lookup_widget(objet_graphique,"InterfaceAfficherTroup");
	if((is_empty(search)==0)  )
	{
		GtkWidget *control=lookup_widget(objet_graphique,"label6");
                gtk_label_set_text(GTK_LABEL(control),"Champ manquant!!");

	}
	else {
	strcpy(ss,gtk_entry_get_text(GTK_ENTRY(search)));
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	gtk_widget_hide (w1);

	treeview = lookup_widget(afficher, "treeview1") ;
	ChercherTroupeau(treeview,ss);
	}

}


void
UpdateTroup                            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{



	Troupeau p;
	GtkWidget *reference,*ref1,*race,*couleur,*poid,*jour, *mois, *annee, *ajouter, *update ;
	char ver[30];

	reference=lookup_widget(objet_graphique,"entry6");
	ref1=lookup_widget(objet_graphique,"combobox1");
	race=lookup_widget(objet_graphique,"entry7");
	couleur=lookup_widget(objet_graphique,"entry8");
	poid=lookup_widget(objet_graphique, "spinbutton5");
	jour=lookup_widget(objet_graphique, "spinbutton6");
	mois=lookup_widget(objet_graphique, "spinbutton7");
	annee=lookup_widget(objet_graphique, "spinbutton8");

if( (is_empty(reference)==0) || (is_empty(race)==0) || (is_empty(couleur)==0) )
{
		GtkWidget *control=lookup_widget(objet_graphique,"label33");
                gtk_label_set_text(GTK_LABEL(control),"Vous devez remplir tous les champs SVP !!");

}
else {
	strcpy(ver,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));
	

	
	strcpy(p.ref,gtk_entry_get_text(GTK_ENTRY(reference)));
	strcpy(p.race,gtk_entry_get_text(GTK_ENTRY(race)));
	strcpy(p.couleur,gtk_entry_get_text(GTK_ENTRY(couleur)));
	
	p.dateDeNaissance.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	p.dateDeNaissance.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	p.dateDeNaissance.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

	p.poid_a_la_naissance=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(poid));


	if((p.dateDeNaissance.jour >= 32) || (p.dateDeNaissance.mois >= 13) ||  (p.dateDeNaissance.annee >= 2099))
{

		GtkWidget *controld=lookup_widget(objet_graphique,"label31");
                gtk_label_set_text(GTK_LABEL(controld),"Format date invalide!!");
}

else {



	ModifierTroupeau(p,ver);

	update=lookup_widget(objet_graphique,"InterfaceUpdateTroup");
	gtk_widget_hide (update);
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListTroupeau(treeview);

	
	
	


}
}

}


void
ValiderReference                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	GtkWidget *combo,*btn;
	combo=lookup_widget(objet_graphique,"combobox1");
	btn=lookup_widget(objet_graphique,"button9");
	gtk_widget_set_sensitive ( btn, FALSE);
	fichierRef();
	
	char ref[10];
	
	FILE *f=NULL;
	f = fopen("reference.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s \n " ,ref)!=EOF)
		gtk_combo_box_append_text (GTK_COMBO_BOX(combo),(ref));
	}
	fclose(f);
	remove("reference.txt");

	

}


void
RemplirChamps                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *ref,*race,*couleur,*poid,*annee,*jour,*mois,*btn,*ref1;
	btn=lookup_widget(objet_graphique,"button8");
	//gtk_widget_set_sensitive ( btn, FALSE);
	ref=lookup_widget(objet_graphique,"entry6");
	ref1=lookup_widget(objet_graphique,"combobox1");
	race=lookup_widget(objet_graphique,"entry7");
	couleur=lookup_widget(objet_graphique,"entry8");
	poid=lookup_widget(objet_graphique,"spinbutton5");
	jour=lookup_widget(objet_graphique,"spinbutton6");
	mois=lookup_widget(objet_graphique,"spinbutton7");
	annee=lookup_widget(objet_graphique,"spinbutton8");
	char var[10];
	strcpy(var,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ref1)));	
	Troupeau t;
	FILE *f=NULL;
	f = fopen("troupeau.txt","r");
	if(f!=NULL)
	{
	  while (fscanf(f,"%s %s %s %d %d %d %d \n " ,t.ref,t.race,t.couleur,&t.poid_a_la_naissance,&t.dateDeNaissance.annee
,&t.dateDeNaissance.mois,&t.dateDeNaissance.jour)!=EOF)

	{
	if(strcmp(var,t.ref)==0)
	{
	gtk_entry_set_text (ref,t.ref);
	gtk_entry_set_text (race,t.race);
	gtk_entry_set_text (couleur,t.couleur);
	gtk_spin_button_set_value (poid, t.poid_a_la_naissance);
	gtk_spin_button_set_value (annee, t.dateDeNaissance.annee);
	gtk_spin_button_set_value (mois, t.dateDeNaissance.mois);
	gtk_spin_button_set_value (jour, t.dateDeNaissance.jour);

	}

	
	}
	}
	fclose(f);
	

}


void
BackUpdate                             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	update=lookup_widget(objet_graphique,"InterfaceUpdateTroup");
	gtk_widget_hide (update);
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListTroupeau(treeview);

}


void
BackAdd                                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

	update=lookup_widget(objet_graphique,"InterfaceAjoutTroupeau");
	gtk_widget_hide (update);
	afficher = create_InterfaceAfficherTroup();
	gtk_widget_show (afficher);
	treeview = lookup_widget(afficher, "treeview1") ;
	AfficherListTroupeau(treeview);

}

