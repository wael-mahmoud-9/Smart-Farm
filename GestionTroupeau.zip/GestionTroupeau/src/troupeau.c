#include "troupeau.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



enum   
{       REF,
        RACE,
	COULEUR,
	POID,
        DATE,
	COLUMNS,
	
};


void AjouterTroupeau(Troupeau c)
{

FILE *f=NULL;

f=fopen("troupeau.txt","a+");

if(f!=NULL)
{

fprintf(f,"%s %s %s %d %d %d %d \n",c.ref,c.race,c.couleur,c.poid_a_la_naissance,
c.dateDeNaissance.annee,c.dateDeNaissance.mois,c.dateDeNaissance.jour);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
}



void AfficherListTroupeau(GtkWidget *liste) {


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char race[30];
	char couleur[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char poid[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Race",renderer, "text",RACE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Couleur",renderer, "text",COULEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Poid",renderer, "text",POID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("troupeau.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("troupeau.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s \n " ,ref,race,couleur,poid,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
		
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, REF,ref, RACE,race, COULEUR,couleur,  POID,poid, DATE,dateComp, -1 );
		
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}


void supprimerTroupeau(char ref[30]){

FILE*f=NULL;
FILE*f1=NULL;
Troupeau c;
f=fopen("troupeau.txt","r");
f1=fopen("ancien.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d \n" ,c.ref,c.race,c.couleur,&c.poid_a_la_naissance
,&c.dateDeNaissance.annee,&c.dateDeNaissance.mois,&c.dateDeNaissance.jour)!=EOF)
{
if(strcmp(ref,c.ref)!=0)
{
fprintf(f1,"%s %s %s %d %d %d %d \n",c.ref,c.race,c.couleur,c.poid_a_la_naissance,
c.dateDeNaissance.annee,c.dateDeNaissance.mois,c.dateDeNaissance.jour);
}
}

fclose(f);
fclose(f1);
remove("troupeau.txt");
rename("ancien.txt","troupeau.txt");
}





void ChercherTroupeau (GtkWidget *liste, char refe[30]) 
{
	
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char ref[30];
	char race[30];
	char couleur[30];
	char jour[30];
	char mois[30];
	char annee[30];
	char poid[30];
	char dateComp[30];
	 
	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Référence",renderer, "text",REF, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Race",renderer, "text",RACE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Couleur",renderer, "text",COULEUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Poid",renderer, "text",POID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
		store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("troupeau.txt","r");

		if(f==NULL)
		{
			return;
		}
		else
		{
			f = fopen("troupeau.txt","a+");
			while (fscanf(f,"%s %s %s %s %s %s %s \n " ,ref,race,couleur,poid,annee,mois,jour)!=EOF)
			{
		 strcpy(dateComp,annee);
	         strcat(dateComp,"-");
		 strcat(dateComp,mois);
 	 	 strcat(dateComp,"-");
		 strcat(dateComp,jour);
    if(strcmp(refe,ref)==0 || strcmp(refe,race)==0  || strcmp(refe,couleur)==0 || strcmp(refe,poid)==0 || strcmp(refe,annee)==0
|| strcmp(refe,dateComp)==0) 			
		
		{
		
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, REF,ref, RACE,race, COULEUR,couleur,  POID,poid, DATE,dateComp, -1 );
		
			}}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref(store);
}
}


}


void ModifierTroupeau(Troupeau c , char ref[30]) {

supprimerTroupeau(ref);
AjouterTroupeau(c);

}




void fichierRef() {

FILE*f=NULL;
FILE*f1=NULL;
Troupeau c;
f=fopen("troupeau.txt","r");
f1=fopen("reference.txt","w+");
while (fscanf(f,"%s %s %s %d %d %d %d \n" ,c.ref,c.race,c.couleur,&c.poid_a_la_naissance
,&c.dateDeNaissance.annee,&c.dateDeNaissance.mois,&c.dateDeNaissance.jour)!=EOF)
{

fprintf(f1,"%s \n",c.ref);

}

fclose(f);
fclose(f1);

}



