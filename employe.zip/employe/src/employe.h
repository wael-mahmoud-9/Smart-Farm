#include <gtk/gtk.h>

struct employe
{

	char nom[30];
	char prenom[30];
	char cin[15];
	char telephone[15];
	char fonction[30];
	int jour;
	int mois;
	int annee;
	char sexe[30];



}; typedef struct employe employe;
struct absence
{

	char nom[30];
	char prenom[30];
	char cin[15];
	int taux;
	int nbabs;
	int nbpr;



}; typedef struct absence absence;

void ajouter_employe(employe e);
int controle(char cin[]);
void afficher_employe(GtkWidget *liste);
void modifier_employe(employe e1);
employe rechercher (char cin[15]);
int supprimer_employe(employe e,char cin[15]);
absence recherch (char cin[15]);
void modifier_abs(absence a1);
absence meilleur ();
