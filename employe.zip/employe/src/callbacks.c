#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "employe.h"
#include<string.h>

GtkWidget *gestionemploye;
GtkWidget *treeAFF;
GtkWidget *notebook1;
GtkWidget *output;


void
on_buttonAJ_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
employe e;

GtkWidget *nom, *prenom, *cin, *telephone,*fonction, *jour, *mois, *annee, *sexeh, *sexef;
GtkWidget *admin,*yt;

gestionemploye=lookup_widget(objet, "gestionemploye");

nom=lookup_widget(objet, "EN");
prenom=lookup_widget(objet, "EP");
cin=lookup_widget(objet, "ECI");
telephone=lookup_widget(objet, "entry4");
fonction=lookup_widget(objet, "ETAF");
jour=lookup_widget(objet, "spinbuttonJA");
mois=lookup_widget(objet, "spinbuttonMA");
annee=lookup_widget(objet, "spinbuttonAA");
sexeh=lookup_widget(objet, "radiobuttonH");
sexef=lookup_widget(objet, "radiobuttonF");

strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(e.telephone,gtk_entry_get_text(GTK_ENTRY(telephone)));
strcpy(e.fonction,gtk_entry_get_text(GTK_ENTRY(fonction)));

e.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(sexeh)))
	{strcpy(e.sexe,"Homme");}
else	{strcpy(e.sexe,"Femme");}

ajouter_employe(e);
yt=create_dialog1();
gtk_widget_show(yt);
}


void
on_buttonCHR_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *eCHR, *prenom, *nom, *cin, *telephone, *fonction, *jour, *mois, *annee, *sexe;
  employe e;
  char cine[9] ;
 

  
  eCHR=lookup_widget(objet, "eCHR");
  strcpy(cine,gtk_entry_get_text(GTK_ENTRY(eCHR)));
  
  e=rechercher(cine);

  FILE* f;
  f=fopen("employes.txt","r");
 
  prenom=lookup_widget (objet,"ePRM");
  nom=lookup_widget (objet,"eNOMM");
  cin=lookup_widget (objet,"eCINM");
  telephone=lookup_widget (objet,"eTELM");
  fonction=lookup_widget (objet,"eTAFM");;
  jour=lookup_widget (objet,"spinbuttonJM");
  mois=lookup_widget (objet,"spinbuttonMM");
  annee=lookup_widget (objet,"spinbuttonAM");
  sexe=lookup_widget (objet,"radiobuttonS");
  gtk_entry_set_text (GTK_ENTRY(prenom),e.prenom);
  gtk_entry_set_text (GTK_ENTRY(nom),e.nom);
  gtk_entry_set_text (GTK_ENTRY(cin),e.cin);
  gtk_entry_set_text (GTK_ENTRY(telephone),e.telephone);
  gtk_entry_set_text (GTK_ENTRY(fonction),e.fonction);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),e.jour);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),e.mois);
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee),e.annee);
  gtk_entry_set_text (GTK_ENTRY(sexe),e.sexe);
  
  
  

  
  fclose(f);
}


void
on_BF_clicked                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gestionemploye=lookup_widget(objet_graphique,"gestionemploye");
notebook1=lookup_widget(gestionemploye,"notebook1");
treeAFF=lookup_widget(gestionemploye,"treeAFF");
afficher_employe(treeAFF);

}



void
on_radiobuttonH_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttonF_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_SUP_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *nom, *prenom, *cin, *telephone, *fonction, *jour, *mois, *annee, *sexe, *outpout;
  employe e;
char cine[9];
int suppri;
  FILE* f;

  prenom=lookup_widget (objet,"ePRM");
  nom=lookup_widget (objet,"eNOMM");
  cin=lookup_widget (objet,"eCINM");
  telephone=lookup_widget (objet,"eTELM");
  fonction=lookup_widget (objet,"eTAFM");;
  jour=lookup_widget (objet,"spinbuttonJM");
  mois=lookup_widget (objet,"spinbuttonMM");
  annee=lookup_widget (objet,"spinbuttonAM");
  sexe=lookup_widget (objet,"radiobuttonS");
   
   outpout=lookup_widget (objet,"ERR");
   strcpy (cine,gtk_entry_get_text(GTK_ENTRY(cin)));
   suppri=supprimer_employe(e,cine);
  if (suppri==1)
   {
  gtk_label_set_text (GTK_LABEL(outpout),"employe supprimé");
	printf("employe supprimé");
   }

}

void
on_buttonMOD_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *prenom, *nom, *cin, *telephone, *fonction, *jour, *mois, *annee, *sexe;
  
  employe e1;

  char cine[9];
  
  
  FILE* f;
  f=fopen("employes.txt","r");

  prenom=lookup_widget (objet,"ePRM");
  nom=lookup_widget (objet,"eNOMM");
  cin=lookup_widget (objet,"eCINM");
  telephone=lookup_widget (objet,"eTELM");
  fonction=lookup_widget (objet,"eTAFM");;
  jour=lookup_widget (objet,"spinbuttonJM");
  mois=lookup_widget (objet,"spinbuttonMM");
  annee=lookup_widget (objet,"spinbuttonAM");
  sexe=lookup_widget (objet,"radiobuttonS");
  
strcpy(e1.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e1.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e1.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(e1.telephone,gtk_entry_get_text(GTK_ENTRY(telephone)));
strcpy(e1.fonction,gtk_entry_get_text(GTK_ENTRY(fonction)));



e1.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e1.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e1.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));



strcpy(e1.sexe,gtk_entry_get_text(GTK_ENTRY(sexe)));




  modifier_employe(e1);
  fclose(f);

}


void
on_AFAC_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
gestionemploye=lookup_widget(objet, "gestionemploye");
gtk_widget_destroy(gestionemploye);
gestionemploye=create_gestionemploye();
gtk_widget_show(gestionemploye);
}


void
on_button6_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *eNAB;
  absence a;
  a=meilleur ();
  eNAB=lookup_widget (objet,"eNAB");
  gtk_entry_set_text (GTK_ENTRY(eNAB),a.cin);
}


void
on_CHAB_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *eABCH, *taux;
  absence a;
  char cine[9] ;
 

  
  eABCH=lookup_widget(objet, "eABCH");
  strcpy(cine,gtk_entry_get_text(GTK_ENTRY(eABCH)));
  
  a=recherch(cine);
  taux=lookup_widget (objet,"spinbuttonT");
  gtk_spin_button_set_value(GTK_SPIN_BUTTON(taux),a.taux);

}


void
on_MQAB_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *cin, *taux, *nbabs, *nbpr;
  
  absence a1;
  absence a2;

  char cine[9];
  
  
  FILE* f;
  f=fopen("abs.txt","r");

  cin=lookup_widget (objet,"eABCH");
  nbabs=lookup_widget (objet,"radiobuttonAB");

strcpy(a1.cin,gtk_entry_get_text(GTK_ENTRY(cin)));

a2=recherch(a1.cin);
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(nbabs)))
	{a2.nbabs++;
	 a2.taux=(100/(a2.nbabs+a2.nbpr))*a2.nbabs;
	}
	
else	{a2.nbpr++;
	 a2.taux=(100/(a2.nbabs+a2.nbpr))*a2.nbabs;
	}

  modifier_abs(a2);
  fclose(f);
}

