#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif




#include <stdio.h>
#include <string.h>
#include "employe.h"
#include <gtk/gtk.h>

enum   
{       NOM,
        PRENOM,
	CIN,
	TELEPHONE,
	FONCTION,
        JOUR,
	MOIS,
	ANNEE,
	SEXE,
	COLUMNS,
	TAUX,
	NBPR,
	NBABS,
};




void ajouter_employe(employe e)
{
  FILE *f;
  FILE *g;
  f=fopen("employes.txt","a+");
  if(f!=NULL) 
{
  fprintf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,e.jour,e.mois,e.annee,e.sexe);
  fclose(f);
}
  g=fopen("absence.txt","a+");
  if(g!=NULL) 
{
  fprintf(g,"%s %s %s 0 0 0\n",e.nom,e.prenom,e.cin);
  fclose(g);
}

}

///////////////////////////////////////////////////////////////////
int supprimer_employe(employe e,char cin[15])
{
    FILE*f;
    FILE*c;
    absence a;
    int suppri=0;
    f=fopen("employes.txt","r+");
    c=fopen("tmp.txt","w+");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,&e.jour,&e.mois,&e.annee,e.sexe)!=EOF)
        {

            if ((strcmp(e.cin,cin)!=0))
            {               
               fprintf(c,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,e.jour,e.mois,e.annee,e.sexe);              
            }
            else
            {
              suppri=1;
            }
        }
    }
fclose(f);
fclose(c);
remove("employes.txt");
rename("tmp.txt","employes.txt");
    f=fopen("absence.txt","r+");
    c=fopen("tmp.txt","w+");
if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
        {

            if ((strcmp(a.cin,cin)!=0))
            {               
               fprintf(c,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,a.taux,a.nbabs,a.nbpr);              
            }
        }
    }
fclose(f);
fclose(c);
remove("absence.txt");
rename("tmp.txt","absence.txt");
return suppri;
}
/////////////////////////////////////////////////////////


void afficher_employe(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char nom[30];
	char prenom[30];
	char cin[15];
	char telephone[15];
	char fonction[30];
	char jour[5];
	char mois[5];
	char annee[6];
	char sexe[30];
	char nbabs[5];
	char nbpr[5];
	char taux[5];
	char jj[30];
	char mm[30];
	char aa[30];

	store=NULL;

	FILE *f;
	FILE *c;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Prenom",renderer, "text",PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Cin",renderer, "text",CIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Telephone",renderer, "text",TELEPHONE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Fonction",renderer, "text",FONCTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


 		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Jour",renderer, "text",JOUR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Mois",renderer, "text",MOIS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Annee",renderer, "text",ANNEE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nombre d'absence",renderer, "text",NBABS, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Nombre de presence",renderer, "text",NBPR, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("Taux d'absence",renderer, "text",TAUX, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		

		store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("employes.txt","r");
		
		c = fopen("absence.txt","r");
		if((f==NULL)&&(c==NULL))
		{
			return;
		}
		else
		{
			f = fopen("employes.txt","a+");
			c = fopen("absence.txt","a+");
			while((fscanf(f,"%s %s %s %s %s %s %s %s %s\n",nom,prenom,cin,telephone,fonction,jour,mois,annee,sexe)!=EOF)&&(fscanf(c,"%s %s %s %s %s %s\n",jj,mm,aa,taux,nbabs,nbpr)!=EOF))
			{
		gtk_list_store_append(store,&iter);
		gtk_list_store_set (store, &iter, NOM, nom, PRENOM, prenom, CIN, cin, TELEPHONE, telephone, FONCTION, fonction, JOUR, jour, MOIS, mois, ANNEE, annee, SEXE, 	sexe, NBABS, nbabs, NBPR, nbpr, TAUX, taux, -1 );
			}
			fclose(f);
			fclose(c);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
 		g_object_unref(store);
}
}
}
////////////////////////////////////////////////////////////////////

void modifier_employe(employe e1)
{
    FILE*f;
    FILE*g;
    employe e;
    absence a;
    char cin[9];
    f=fopen("employes.txt","r");
    g=fopen("tmp.txt","a+");

    
    if(f!=NULL)
    { if(g!=NULL)
    { 
        while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,&e.jour,&e.mois,&e.annee,e.sexe)!=EOF)
        {
		printf("\n %s \n",e1.cin);
            if(strcmp(e.cin,e1.cin)!=0)
            {
                fprintf(g,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,e.jour,e.mois,e.annee,e.sexe);	
			printf("\n ok \n");

            }
            else
            { printf("\n ok1 \n");



                fprintf(g,"%s %s %s %s %s %d %d %d %s\n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.fonction,e1.jour,e1.mois,e1.annee,e1.sexe);
            }
        }
        fclose(f);
        fclose(g);
remove("employes.txt");
rename("tmp.txt","employes.txt");
    }
    }
    
    f=fopen("absence.txt","r");
    g=fopen("tmp.txt","a+");

    
    if(f!=NULL)
    { if(g!=NULL)
    { 
        while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
        {
		printf("\n %s \n",e1.cin);
            if(strcmp(a.cin,e1.cin)!=0)
            {
                fprintf(g,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,a.taux,a.nbabs,a.nbpr);	
			printf("\n ok \n");

            }
            else
            { printf("\n ok1 \n");



                fprintf(g,"%s %s %s %d %d %d\n",e1.nom,e1.prenom,e1.cin,a.taux,a.nbabs,a.nbpr);
            }
        }
        fclose(f);
        fclose(g);
remove("absence.txt");
rename("tmp.txt","absence.txt");

    }}

}
////////////////////////////////////////////////////////////////////
employe rechercher (char cin[30])
{
    FILE*f;

employe e;
    

    f=fopen("employes.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %s %s %d %d %d %s\n",e.nom,e.prenom,e.cin,e.telephone,e.fonction,&e.jour,&e.mois,&e.annee,e.sexe)!=EOF)
    {
        if((strcmp(e.cin,cin)==0))
        {
	 printf("ok \n");
	return e;
fclose(f);
	}
        
		strcpy(e.nom,"erreur");
		strcpy(e.prenom,"erreur");
		strcpy(e.cin,"erreur");
               
                
                

			    
    }
	
    fclose (f);}
    return e;

}



///////////////////////////////////////////////////
absence recherch (char cin[30])
{
    FILE*f;

absence a;
    

    f=fopen("absence.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
    {
        if((strcmp(a.cin,cin)==0))
        {
	 printf("ok \n");
	
	fclose(f);
	return a;
	}
        
		a.taux=-99;
                
        }
	
    fclose (f);}
    return a;

}
/////////////////////////////////////////////////////////
void modifier_abs(absence a1)
{
    FILE*f;
    FILE*g;
    absence a;
    char cin[9];
    f=fopen("absence.txt","r");
    g=fopen("tmp.txt","a+");

    
    if(f!=NULL)
    { if(g!=NULL)
    { 
        while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
        {
		printf("\n %s \n",a1.cin);
            if(strcmp(a.cin,a1.cin)!=0)
            {
                fprintf(g,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,a.taux,a.nbabs,a.nbpr);	
			printf("\n oki \n");

            }
            else
            { printf("\n oki1 \n");



                fprintf(g,"%s %s %s %d %d %d\n",a1.nom,a1.prenom,a1.cin,a1.taux,a1.nbabs,a1.nbpr);
            }
        }
        fclose(f);
        fclose(g);
remove("absence.txt");
rename("tmp.txt","absence.txt");

    }}
}
//////////////////////////////////////////////////////
absence meilleur ()
{
    FILE*f;

absence a;
absence a1;
    int t=101;

    f=fopen("absence.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
    {
     if(a.taux < t)
        {
	 t=a.taux;
	 a1=a;
	}
                
    }
	
    fclose (f);}
    return a1;

}
/*
absence meilleur()
{
	FILE *f;
absence a;
absence a1;
int som=0;
    f=fopen("absence.txt","r");
if(f!=NULL){
    while(fscanf(f,"%s %s %s %d %d %d\n",a.nom,a.prenom,a.cin,&a.taux,&a.nbabs,&a.nbpr)!=EOF)
	{
		if(a1.cin==a.cin)
			{ 
				a.taux=som++;
			}
	fclose(f);}

	if(a.taux<a1.taux)
		{ return a1.taux;}
	else {return a.taux;}
}
	
*/				








